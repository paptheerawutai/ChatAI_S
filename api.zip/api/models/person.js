import mongoose from 'mongoose';

const personSchema = new mongoose.Schema({
    title: {
        type : String
    },
    detail:{
        type : String
    },
    color : {
        type : String
    },
    sex :{
        type : String
    },
    enabled : {
        type : Boolean
    }
} , { timestamps : true });

const Person = mongoose.model('persons', personSchema);
export default Person;
