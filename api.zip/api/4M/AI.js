
import express from "express";
import mongoose from "mongoose";
import Joi from "joi";
import { authenticateApiKey, requireAdmin, optionalAuth } from "../middleware/auth.js";

const router = express.Router();

// Input validation schemas
const conditionValidationSchema = Joi.object({
  problem_name: Joi.string().max(200).optional(),
  injection: Joi.object().optional(),
  temperature_setting: Joi.object().optional(),
  hotrunner: Joi.object().optional(),
  holding_injection: Joi.object().optional(),
  screw_rotate: Joi.object().optional(),
  mold_close: Joi.object().optional(),
  mold_open: Joi.object().optional(),
  ejector: Joi.object().optional(),
  core_setting: Joi.object().optional(),
  valve_gate_sec: Joi.object().optional(),
  lubrication: Joi.object().optional(),
  datacondition_part: Joi.object().optional(),
}).min(1); // ต้องมีอย่างน้อย 1 field

// ✅ Schema สำหรับผลต่าง
const conditionDiffSchema = new mongoose.Schema({ diff: Object }, { timestamps: true });
let ConditionDiff;
router.use((req, res, next) => {
  if (!ConditionDiff) {
    const db4m = req.app.locals.db4m;
    if (!db4m) {
      console.error("❌ db4m connection not found in app.locals");
      return res.status(500).json({ error: "DB connection not available in app.locals" });
    }
    ConditionDiff = db4m.model("ConditionDiff", conditionDiffSchema);
  }
  next();
});

// ✅ Schema
const conditionSchema = new mongoose.Schema(
  {
    id: Number,
    problem_name: String,
    old: {
      injection: Object,
      temperature_setting: Object,
      hotrunner: Object,
      holding_injection: Object,
      screw_rotate: Object,
      mold_close: Object,
      mold_open: Object,
      ejector: Object,
      core_setting: Object,
      valve_gate_sec: Object,
      lubrication: Object,
      datacondition_part: Object,
    },
    new: {
      injection: Object,
      temperature_setting: Object,
      hotrunner: Object,
      holding_injection: Object,
      screw_rotate: Object,
      mold_close: Object,
      mold_open: Object,
      ejector: Object,
      core_setting: Object,
      valve_gate_sec: Object,
      lubrication: Object,  
      datacondition_part: Object,
    },
    diff: {
      id: Number,
      injection: Object,
      temperature_setting: Object,
      hotrunner: Object,
      holding_injection: Object,
      screw_rotate: Object,
      mold_close: Object,
      mold_open: Object,
      ejector: Object,
      core_setting: Object,
      valve_gate_sec: Object,
      lubrication: Object,  
      datacondition_part: Object,
    }
  }

);

// ✅ Model (ป้องกัน OverwriteModelError)
let Condition;
router.use((req, res, next) => {
  if (!Condition) {
    const db4m = req.app.locals.db4m;
    if (!db4m) {
      console.error("❌ db4m connection not found in app.locals");
      return res
        .status(500)
        .json({ error: "DB connection not available in app.locals" });
    }
    Condition = db4m.model("Condition", conditionSchema);
  }
  next();
});

// ✅ ค่าเริ่มต้น local (เผื่อ DB ว่าง)
let condition_standard = {
  injection: {
    inj_time: "6",
    cooling_time: "23",
    cycle_time: "53",
    cushion: "15",
    scw_monitor: "24",
    bp_pressure: "5",
    clamping_force: "100",
    oil_temp: "40",
  },
  temperature_setting: {
    A: { Z1: "200", Z2: "200", Z3: "", Z4: "", Z5: "", Z6: "", Z7: "", Z8: "" },
    B: { Z1: "", Z2: "", Z3: "", Z4: "", Z5: "", Z6: "", Z7: "", Z8: "" },
  },
  holding_injection: { /* … ตัดทอนเพื่อความสั้น */ },
  screw_rotate: { /* … */ },
  mold_close: { /* … */ },
  mold_open: { /* … */ },
  ejector: { /* … */ },
  core_setting: { /* … */ },
  valve_gate_sec: { ON: {}, OFF: {} },
  lubrication: { lubCount: "100", lubTime: "100" },
};



// �️ Transient cache (ไม่บันทึกลงฐานข้อมูล)
let transientCondition = null;
let transientUpdatedAt = null;

// 📥 POST/GET สำหรับ cache ชั่วคราว (ต้องการ authentication)
router.post("/condition_transient", authenticateApiKey, (req, res) => {
  try {
    // Input validation
    const { error, value } = conditionValidationSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ 
        error: "Invalid input", 
        details: error.details.map(d => d.message) 
      });
    }

    transientCondition = value;
    transientUpdatedAt = new Date().toISOString();

    res.status(202).json({
      message: "Transient condition stored",
      updated_at: transientUpdatedAt,
    });
  } catch (err) {
    console.error("❌ Transient condition error:", err.message);
    res.status(500).json({ error: "Server error" });
  }
});

router.get("/condition_transient", authenticateApiKey, (req, res) => {
  if (!transientCondition) {
    return res.status(404).json({
      error: "No transient condition stored",
    });
  }

  // ถ้า payload มีฟิลด์ condition.condition ให้คืนเฉพาะฟอร์มเหมือน /condition_standard
  if (transientCondition.condition && transientCondition.condition.condition) {
    return res.json({
      condition_standard: transientCondition.condition.condition
    });
  }

  // fallback: คืน payload เดิม
  res.json({
    condition: transientCondition,
    updated_at: transientUpdatedAt,
  });
});




// 📌 GET → อ่านค่าล่าสุด (public access)
router.get("/condition_standard", optionalAuth, async (req, res) => {
  try {
    // อ่าน document ที่ id มากสุด (ล่าสุด) - ป้องกัน NoSQL injection
    const latest = await Condition.findOne({}).sort({ id: -1 }).lean();
    if (latest && latest.new) {
      res.json({ condition_standard: latest.new });
    } else {
      res.json({ condition_standard });
    }
  } catch (err) {
    console.error("❌ DB Error:", err.message);
    res.status(500).json({ error: "Database error occurred" });
  }
});

router.get("/condition_standard1", async (req, res) => {
  try {
    const all = await Condition.find();
    // คืน array ของข้อมูลใหม่ทั้งหมด
    const result = all.map(doc => doc.new ? doc.new : doc);
    res.json({ condition_standard: result });
  } catch (err) {
    console.error("❌ DB Error:", err.message);
    res.status(500).json({ error: "Database error occurred" });
  }
});

// router.get("/diff", async (req, res) => {
//   try {
//     const all = await Condition.find();
//     // คืน array ของข้อมูลใหม่ทั้งหมด
//     const result = all.map(doc => doc.diff ? doc.diff : doc);
//     res.json({ condition_standard: result });
//   } catch (err) {
//     console.error("❌ DB Error:", err.message);
//     res.status(500).json({ error: "DB Error", detail: err.message });
//   }
// });

// 📌 GET → ดึงข้อมูลเก่าทั้งหมด + ข้อมูลใหม่ล่าสุด
router.get("/condition_old_new", async (req, res) => {
  try {
    const all = await Condition.find().sort({ id: 1 });
    const latest = await Condition.findOne().sort({ id: -1 });
    res.json({ old: all, new: latest });
  } catch (err) {
    console.error("❌ DB Error:", err.message);
    res.status(500).json({ error: "Database error occurred" });
  }
});


// 📌 GET → อ่านทั้งหมด
// 📌 GET → อ่านล่าสุดแบบฟอร์มเดียว (ไม่ใช่ array)
// 📌 GET → นับจำนวน record ใน collection
router.get("/condition_count", async (req, res) => {
  try {
    const count = await Condition.countDocuments();
    // ถ้าไม่มีข้อมูลคืน 0 ถ้ามีคืนจำนวน record (เริ่มนับจาก 1)
    res.json({ count: count });
  } catch (err) {
    console.error("❌ DB Error:", err.message);
    res.status(500).json({ error: "Database error occurred" });
  }
});


router.get("/diff", async (req, res) => {
  try {
    const all = await Condition.find();
    // ฟังก์ชันกรองเฉพาะค่าที่ไม่ใช่ 0 (recursive)
    function filterZeroDiff(obj) {
      if (typeof obj !== 'object' || obj === null) return undefined;
      if (Array.isArray(obj)) {
        const arr = obj.map(filterZeroDiff).filter(v => v !== undefined && (typeof v !== 'object' || Object.keys(v).length > 0));
        return arr.length > 0 ? arr : undefined;
      }
      const result = {};
      for (const key in obj) {
        if (key === 'id') {
          result[key] = obj[key];
          continue;
        }
        const value = obj[key];
        if (typeof value === 'object' && value !== null) {
          const filtered = filterZeroDiff(value);
          if (filtered !== undefined && Object.keys(filtered).length > 0) {
            result[key] = filtered;
          }
        } else if (typeof value === 'number' && value !== 0) {
          result[key] = value;
        }
      }
      // ถ้ามีแค่ id ให้คืนแค่ id
      if (Object.keys(result).length === 1 && result.id !== undefined) {
        return { id: result.id };
      }
      // ถ้าไม่มี field ที่ไม่ใช่ 0 เลย (นอกจาก id) ให้คืน undefined
      if (Object.keys(result).length === 0) {
        return undefined;
      }
      return result;
    }
    // คืน array ของ diff ที่ไม่ใช่ 0 พร้อม problem_name
    const result = all.map(doc => {
      const diffObj = doc.diff ? filterZeroDiff(doc.diff) : { id: doc.id };
      if (diffObj !== undefined) {
        // ใส่ problem_name ถ้ามี
        return { ...diffObj, problem_name: doc.problem_name };
      }
      return undefined;
    }).filter(obj => obj !== undefined);
    res.json({ condition_standard: result });
  } catch (err) {
    console.error("❌ DB Error:", err.message);
    res.status(500).json({ error: "Database error occurred" });
  }
});




// 📌 POST → บันทึกใหม่ (ต้องการ authentication)
router.post("/condition_standard", authenticateApiKey, async (req, res) => {
  try {
    // Input validation
    const { error, value } = conditionValidationSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ 
        error: "Invalid input", 
        details: error.details.map(d => d.message) 
      });
    }

    // ดึงข้อมูลเก่าจากฐานข้อมูล (ล่าสุด)
    const latest = await Condition.findOne().sort({ id: -1 });
    let oldData = latest ? latest.new || latest : null;

    // หา id ถัดไป
    let nextId = 1;
    if (latest && typeof latest.id === "number") {
      nextId = latest.id + 1;
    }

    // สร้างข้อมูลใหม่ (ใช้ validated data)
    const { problem_name, ...rest } = value;
    const newData = { ...rest, id: nextId };

    // คำนวณ diff เฉพาะ field ที่เป็นตัวเลข
    function calcDiff(oldObj, newObj) {
      if (!oldObj || !newObj) return {};
      const diff = {};
      for (const key in newObj) {
        if (typeof newObj[key] === 'object' && oldObj[key]) {
          diff[key] = calcDiff(oldObj[key], newObj[key]);
        } else if (!isNaN(Number(newObj[key])) && !isNaN(Number(oldObj[key]))) {
          diff[key] = Number(newObj[key]) - Number(oldObj[key]);
        }
      }
      return diff;
    }

    const diffData = calcDiff(oldData, newData);

      // เพิ่ม id ให้ diff ตาม schema
      const diffWithId = { id: nextId, ...diffData };
      // สร้าง document แบบ {id, problem_name, old, new, diff}
      const doc = { id: nextId, problem_name, old: oldData, new: newData, diff: diffWithId };
    const newCondition = new Condition(doc);
    await newCondition.save();

    condition_standard = newData; // update local cache
    console.log("📥 บันทึกเข้า MongoDB:", doc);

      res.status(201).json({
        message: "Condition saved",
        old: oldData,
        new: newData,
        diff: diffWithId
      });
  } catch (err) {
    console.error("❌ MongoDB Save Error:", err.message);
    res.status(500).json({ error: "Failed to save data" });
  }
});
export default router;


