import crypto from 'crypto';

// 🔑 API Key Authentication Middleware
const authenticateApiKey = (req, res, next) => {
  const authMode = process.env.AUTH_MODE || 'development';
  
  // ถ้าปิดการใช้งาน auth ใน development
  if (authMode === 'disabled') {
    console.log('🔓 Authentication disabled');
    return next();
  }

  const apiKey = req.get('X-API-Key') || req.get('Authorization')?.replace('Bearer ', '') || req.query.api_key;
  
  if (!apiKey) {
    return res.status(401).json({
      error: 'API Key required',
      message: 'Please provide API key in X-API-Key header, Authorization header, or api_key query parameter'
    });
  }

  // ตรวจสอบ API Key
  const validKeys = [
    process.env.ADMIN_API_KEY,
    process.env.CLIENT_API_KEY,
    process.env.DEVELOPMENT_API_KEY
  ].filter(Boolean);

  if (!validKeys.includes(apiKey)) {
    return res.status(403).json({
      error: 'Invalid API Key',
      message: 'The provided API key is not valid or has been revoked'
    });
  }

  // เก็บข้อมูล API key type ใน request
  req.apiKeyType = getApiKeyType(apiKey);
  req.isAuthenticated = true;
  
  console.log(`🔑 Authenticated with ${req.apiKeyType} key`);
  next();
};

// ตรวจสอบประเภทของ API Key
const getApiKeyType = (apiKey) => {
  if (apiKey === process.env.ADMIN_API_KEY) return 'admin';
  if (apiKey === process.env.CLIENT_API_KEY) return 'client';
  if (apiKey === process.env.DEVELOPMENT_API_KEY) return 'development';
  return 'unknown';
};

// 🛡️ Authorization middleware สำหรับ admin functions
const requireAdmin = (req, res, next) => {
  if (req.apiKeyType !== 'admin') {
    return res.status(403).json({
      error: 'Admin access required',
      message: 'This endpoint requires admin privileges'
    });
  }
  next();
};

// 📝 Optional authentication (ไม่บังคับ แต่ถ้ามีจะเก็บข้อมูล)
const optionalAuth = (req, res, next) => {
  const authMode = process.env.AUTH_MODE || 'development';
  
  if (authMode === 'disabled') {
    return next();
  }

  const apiKey = req.get('X-API-Key') || req.get('Authorization')?.replace('Bearer ', '');
  
  if (apiKey) {
    const validKeys = [
      process.env.ADMIN_API_KEY,
      process.env.CLIENT_API_KEY,
      process.env.DEVELOPMENT_API_KEY
    ].filter(Boolean);

    if (validKeys.includes(apiKey)) {
      req.apiKeyType = getApiKeyType(apiKey);
      req.isAuthenticated = true;
    }
  }
  
  next();
};

// 🔐 Generate secure API key helper
const generateApiKey = (prefix = 'mai4m') => {
  const randomBytes = crypto.randomBytes(32).toString('hex');
  const timestamp = Date.now().toString(36);
  return `${prefix}-${timestamp}-${randomBytes.substring(0, 20)}`;
};

export { 
  authenticateApiKey, 
  requireAdmin, 
  optionalAuth, 
  generateApiKey 
};