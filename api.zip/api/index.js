import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import mongoSanitize from 'express-mongo-sanitize';
import http from 'http';
import { fileURLToPath, pathToFileURL } from 'url';
import path from 'path';
import { readdirSync } from 'fs';
import 'dotenv/config';
import { authenticateApiKey, optionalAuth, generateApiKey } from './middleware/auth.js';

const app = express();

// ----- resolve __dirname (ESM) -----
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// ----- โหลดค่าจาก .env -----
const MONGODB_URI = process.env.MONGODB_URI;


// ----- Security Middlewares -----
app.use(helmet()); // เพิ่ม security headers

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 นาที
  max: 100, // จำกัด 100 requests ต่อ IP ต่อ 15 นาที
  message: { error: 'Too many requests, please try again later' },
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);


// CORS - กำหนด specific origins แทนการเปิดทุก origin
const corsOptions = {
  origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : ['http://localhost:3000'],
  credentials: true,
};
app.use(cors(corsOptions));

// Body parser with size limits
app.use(express.json({ limit: '10mb' })); // จำกัดขนาด JSON
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

// NoSQL Injection protection
app.use(mongoSanitize());

// Security middleware - ตรวจสอบ suspicious headers
app.use((req, res, next) => {
  const userAgent = req.get('User-Agent') || '';
  const suspiciousPatterns = [
    /sqlmap/i,
    /nikto/i,
    /nessus/i,
    /burp/i,
    /nmap/i,
    /masscan/i,
    /acunetix/i,
    /w3af/i
  ];
  
  if (suspiciousPatterns.some(pattern => pattern.test(userAgent))) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  next();
});

// ----- โหลด routes แบบปลอดภัย -----
async function loadRoutesFrom(dirName, mountPath) {
  const dirPath = path.join(__dirname, dirName);
  let files = [];
  try {
    files = readdirSync(dirPath, { withFileTypes: true })
      .filter(d => d.isFile() && d.name.toLowerCase().endsWith('.js'))
      .map(d => d.name);
  } catch {
    console.warn(`⚠️  Skip routes: folder "${dirName}" not found.`);
    return;
  }

  for (const file of files) {
    const fileUrl = pathToFileURL(path.join(dirPath, file)).href;
    try {
      const mod = await import(fileUrl);
      // ต้อง export default เป็น express.Router เท่านั้น
      const router = mod.default;
      if (typeof router === 'function') {
        app.use(mountPath, router);
        console.log(`➡️  Mounted ${mountPath}/${file}`);
      } else {
        throw new TypeError('Module does not export a router');
      }
    } catch (err) {
      console.error(`❌ Failed to load route "${dirName}/${file}":`, err);
    }
  }
}

// ----- เชื่อมต่อ DB หลักก่อนค่อย start server -----
async function start() {
  try {
    if (!MONGODB_URI) throw new Error('MONGODB_URI is empty. Put it in .env');

    await mongoose.connect(MONGODB_URI);
    console.log('✅ DB connected (Condition)');

    // เก็บ connection สำหรับ 4M routes
    app.locals.db4m = mongoose.connection;

    // 🔑 Authentication info endpoint (public)
    app.get('/auth/info', (req, res) => {
      const authMode = process.env.AUTH_MODE || 'development';
      res.json({
        authMode,
        message: authMode === 'disabled' ? 'Authentication is disabled' : 'API key required for protected endpoints',
        keyTypes: ['admin', 'client', 'development'],
        headers: ['X-API-Key', 'Authorization (Bearer)', 'Query: api_key']
      });
    });

    // 🔑 Generate API key endpoint (for development)
    app.post('/auth/generate', optionalAuth, (req, res) => {
      if (process.env.NODE_ENV === 'production') {
        return res.status(403).json({ error: 'Not available in production' });
      }
      
      const newKey = generateApiKey();
      res.json({
        message: 'New API key generated (development only)',
        apiKey: newKey,
        note: 'Add this key to your .env file for permanent use'
      });
    });

    // เมื่อ DB พร้อมแล้วค่อย mount routes และ start server
    await loadRoutesFrom('MAI', '/MAI');
    await loadRoutesFrom('4M',  '/4M');

    // 🏥 Health check (public endpoint)
    app.get('/health', optionalAuth, (req, res) => {
      const dbStatus = mongoose.connection.readyState;
      const authMode = process.env.AUTH_MODE || 'development';
      
      res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        database: dbStatus === 1 ? 'connected' : 'disconnected',
        version: '1.0.0',
        auth: {
          mode: authMode,
          authenticated: req.isAuthenticated || false,
          keyType: req.apiKeyType || 'none'
        }
      });
    });

    // Global Error Handler - ซ่อนรายละเอียด error ใน production
    app.use((err, req, res, next) => {
      console.error('❌ Server Error:', err);
      
      const isDevelopment = process.env.NODE_ENV === 'development';
      res.status(err.status || 500).json({
        error: 'Internal Server Error',
        ...(isDevelopment && { details: err.message, stack: err.stack })
      });
    });

    // 404 Handler
    app.use('*', (req, res) => {
      res.status(404).json({ error: 'Route not found' });
    });

    const server = http.createServer(app);
    const port = process.env.PORT || 5005;
    server.listen(port, () => console.log(`🚀 Server is running on port ${port}`));
  } catch (err) {
    console.error('❌ Startup error:', err.message);
    console.error('ℹ️  Hints: check IP whitelist, username/password, and URI encoding.');
  }
}

start();

// ป้องกันล้มทั้งโปรเซส
process.on('unhandledRejection', (r) => console.error('UNHANDLED REJECTION:', r));
process.on('uncaughtException', (e) => console.error('UNCAUGHT EXCEPTION:', e));