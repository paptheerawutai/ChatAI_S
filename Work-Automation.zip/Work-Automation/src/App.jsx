import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import MOLDCLOSE from './components/MOLDCLOSE';
import INJECTIONActual from './components/INJECTIONActual';
import EJECTOR from './components/EJECTOR';
import SCREW_ROTATE from './components/SCREW_ROTATE';
import HOLDING_INJECTION from './components/HOLDING_INJECTION';
import Navbar from './components/Navbar';
import Page_all from './components/page_all';
import MOLDCLOSE from './components/MOLDCLOSE';
import MOLDOPEN from './components/MOLDOPEN';
import TEMP from './components/TEMP';
import Hotrunner from './components/Hotrunner';
import ValveGate from './components/ValveGate';
import CORESETTING from './components/CORESETTING';
import LAB from './components/LAB';
import Page_all1 from './components/Page_all1';
import ChatLLM from './components/ChatLLM';
import Datacondition_part from './components/Datacondition_part';
import LLM_AI from './components/LLM_AI';
import App_main from './main/main';

function App() {
  return (
    <Router>
      {/* <Navbar /> */}
      {/* <ChatLLM /> */}
      <Routes>
        {/* <Route path="/" element={<MOLDCLOSE />} /> */}
        <Route path="/" element={<Page_all1 />} />
        <Route path="/dd" element={<Page_all />} />
        <Route path="/LLM" element={<Page_all1 />} />
        <Route path="/Datacondition_part" element={<Datacondition_part />} />
        <Route path="/chat-llm" element={<LLM_AI/>} />
        <Route path="/main" element={<App_main/>} />

        <Route path="/injection-actual" element={<INJECTIONActual />} />
        <Route path="/ejector" element={<EJECTOR />} />
        <Route path="/screw-rotate" element={<SCREW_ROTATE />} />
        <Route path="/holding-injection" element={<HOLDING_INJECTION />} />
        <Route path="/mold-close" element={<MOLDCLOSE />} />
        <Route path="/mold-open" element={<MOLDOPEN />} />
        <Route path="/temperature" element={<TEMP />} />
        <Route path='/hotrunner' element={<Hotrunner />} />

        <Route path='/valve-gate' element={<ValveGate />} />
        <Route path='/core-setting' element={<CORESETTING />} />
        <Route path='/lab' element={<LAB/>} />
        {/* <Route path='/chat-llm' element={<ChatLLM/>} /> */}
        {/* <Route path="/add" element={</>} /> */}
      </Routes>
    </Router>
  );
}

export default App;
