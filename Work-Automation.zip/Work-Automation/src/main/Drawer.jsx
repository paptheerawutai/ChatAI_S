import React from "react";

function Drawer({ 
  drawerOpen, 
  setDrawerOpen, 
  wsUrl, 
  setWsUrl, 
  apiUrl, 
  setApiUrl, 
  model, 
  setModel, 
  CONDITION_URL_DEFAULT 
}) {
  return (
    <>
      {/* Overlay */}
      <div
        className={`drawer-overlay ${drawerOpen ? "open" : ""}`}
        onClick={() => setDrawerOpen(false)}
      />

      {/* Drawer */}
      <aside className={`drawer ${drawerOpen ? "open" : ""}`}>
        <div className="drawer-header">
          <div className="drawer-title">การตั้งค่า</div>
          <button
            className="btn secondary close-btn"
            onClick={() => setDrawerOpen(false)}
            style={{
              height: '36px',
              padding: '0 12px',
              minWidth: '36px'
            }}
          >
            ✕
          </button>
        </div>

        <div className="drawer-body">
          <div className="field">
            <label htmlFor="drawer-ws-url">WebSocket URL</label>
            <input 
              id="drawer-ws-url"
              type="url"
              value={wsUrl} 
              onChange={(e) => setWsUrl(e.target.value)}
              placeholder="ws://..."
            />
          </div>

          <div className="field">
            <label htmlFor="drawer-api-url">HTTP Fallback URL</label>
            <input 
              id="drawer-api-url"
              type="url"
              value={apiUrl} 
              onChange={(e) => setApiUrl(e.target.value)}
              placeholder="http://..."
            />
          </div>

          <div className="field">
            <label htmlFor="drawer-model">Model</label>
            <select 
              id="drawer-model"
              value={model} 
              onChange={(e) => setModel(e.target.value)}
            >
              <option value="gpt-4o-mini">gpt-4o-mini</option>
              <option value="gpt-4o">gpt-4o</option>
              <option value="o4-mini">o4-mini</option>
            </select>
          </div>

          <div className="field">
            <label>Temperature (คงที่ในโค้ด)</label>
            <input 
              type="text"
              value="0.2" 
              disabled 
              style={{
                background: '#f9fafb',
                cursor: 'not-allowed'
              }}
            />
          </div>

          <div className="field">
            <label>Condition URL (คงที่ในโค้ด)</label>
            <input 
              type="text"
              value={CONDITION_URL_DEFAULT} 
              disabled 
              style={{
                background: '#f9fafb',
                cursor: 'not-allowed',
                fontSize: '12px'
              }}
            />
          </div>
        </div>

        <div className="drawer-footer">
          💡 เปลี่ยนค่าแล้วใช้ทันทีในการส่งครั้งถัดไป
        </div>
      </aside>
    </>
  );
}

export default Drawer;