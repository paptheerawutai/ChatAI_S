import React, { useState, useEffect, useRef, useCallback } from "react";
import Chat_Drawer from "./Chat_Drawer";
import Drawer from "./Drawer";
import MiniComposer from "./MiniComposer";
import { useApi } from "../contexts/ApiContext";

import "./css/styles.css";
import "./css/main.css";
import "./css/Drawer.css";

const collapseTailDuplicates = (value) => {
  if (!value) return value;
  const units = Array.from(value);
  const maxWindow = Math.min(8, Math.floor(units.length / 2));

  let changed = true;
  while (changed && units.length >= 2) {
    changed = false;
    const currentMax = Math.min(maxWindow, Math.floor(units.length / 2));
    for (let size = currentMax; size >= 1; size--) {
      const start = units.length - size * 2;
      if (start < 0) continue;

      const first = units.slice(start, start + size).join("");
      const second = units.slice(start + size, start + size * 2).join("");

  // treat repeated chunks containing letters or digits as duplicates, remove trailing copy
  if (first === second && /[\p{L}\p{N}]/u.test(first)) {
        units.splice(start + size, size);
        changed = true;
        break;
      }
    }
  }

  return units.join("");
};

function App_main() {
  // ===== API Context =====
  const { handleRead_ai, handleButtonClick } = useApi();
  // ===== Constants =====
  const TEMPERATURE_DEFAULT = 0.2;
  const CONDITION_URL_DEFAULT = "http://172.20.10.3:5005/4m/condition_standard1";

  // ===== States =====
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [miniOpen, setMiniOpen] = useState(false);
  const [chatLog, setChatLog] = useState([]);
  // const [wsUrl, setWsUrl] = useState("ws://172.20.10.4:8000/ws/chat_condition");
   const [wsUrl, setWsUrl] = useState("ws://172.20.10.3:1880/ws/chat_condition");
  const [apiUrl, setApiUrl] = useState("http://172.20.10.4:8000/api/chat_condition");
  const [model, setModel] = useState("gpt-4o-mini");
  const [status, setStatus] = useState("WS: disconnected");
  const [isConnected, setIsConnected] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [lastMessageType, setLastMessageType] = useState("คำถาม"); // เก็บประเภทข้อความล่าสุด

  // ===== Refs =====
  const wsRef = useRef(null);
  const streamingRef = useRef(null);
  const reconnectTimerRef = useRef(null);
  const shouldReconnectRef = useRef(true);
  const chunkCountRef = useRef(0);

  // ===== Update Status =====
  const updateWSStatus = useCallback((connected) => {
    setIsConnected(connected);
    setStatus(connected ? "WS: connected" : "WS: disconnected");
  }, []);

  // ===== Add Message =====
  const addMessage = useCallback((who, text) => {
    setChatLog((prev) => [...prev, { who, text, id: Date.now() + Math.random() }]);
  }, []);

  // ===== Update Streaming Message =====
  const updateStreaming = useCallback((incomingText) => {
    setChatLog((prev) => {
      // ต้องมี streaming bubble อยู่แล้ว
      if (streamingRef.current !== null && 
          streamingRef.current >= 0 && 
          streamingRef.current < prev.length) {
        const updated = [...prev];
        const bubble = updated[streamingRef.current];
        const nextText = typeof incomingText === "string" ? incomingText : "";

        if (nextText.startsWith(bubble.text)) {
          bubble.text = nextText;
        } else if (!bubble.text) {
          bubble.text = nextText;
        } else {
          bubble.text += nextText;
        }

        chunkCountRef.current += 1;
        console.log(
          `[Streaming] chunk #${chunkCountRef.current}`,
          {
            index: streamingRef.current,
            length: bubble.text.length,
            preview: bubble.text.slice(0, 60),
          }
        );
        bubble.text = collapseTailDuplicates(bubble.text);
        return updated;
      }
      // ไม่ควรมาถึงตรงนี้
      console.warn('[Streaming] No bubble found, creating new one');
      streamingRef.current = prev.length;
      chunkCountRef.current += 1;
      const initial = typeof incomingText === "string" ? incomingText : "";
      return [
        ...prev,
        {
          who: "bot",
          text: collapseTailDuplicates(initial),
          id: Date.now() + Math.random(),
        },
      ];
    });
  }, []);

  // ===== WebSocket Connect =====
  const connectWS = useCallback(() => {
    const url = wsUrl.trim();
    if (!url) {
      updateWSStatus(false);
      return;
    }

    // ป้องกันการสร้าง connection ซ้ำ
    if (wsRef.current && 
        (wsRef.current.readyState === WebSocket.OPEN || 
         wsRef.current.readyState === WebSocket.CONNECTING)) {
      return;
    }

    let socket;
    try {
      socket = new WebSocket(url);
    } catch (error) {
      console.error('[WS] Connection failed:', error);
      updateWSStatus(false);
      return;
    }

    wsRef.current = socket;

    socket.onopen = () => {
      console.log('[WS] Connected');
      updateWSStatus(true);
    };

    socket.onclose = () => {
      console.log('[WS] Disconnected');
      updateWSStatus(false);
      streamingRef.current = null;
      
      // Auto-reconnect
      if (shouldReconnectRef.current) {
        if (reconnectTimerRef.current) {
          clearTimeout(reconnectTimerRef.current);
        }
        reconnectTimerRef.current = setTimeout(() => {
          connectWS();
        }, 1500);
      }
    };

    socket.onerror = (error) => {
      console.error('[WS] Error:', error);
      updateWSStatus(false);
    };

    socket.onmessage = (ev) => {
      try {
        const j = JSON.parse(ev.data);
        if (j.event === "chunk") {
          updateStreaming(j.text || "");
        } else if (j.event === "end") {
          const finishedIndex = streamingRef.current;
          streamingRef.current = null;
          if (finishedIndex !== null && finishedIndex >= 0) {
            setChatLog((prev) => {
              if (finishedIndex < prev.length) {
                const updated = [...prev];
                updated[finishedIndex] = {
                  ...updated[finishedIndex],
                  text: collapseTailDuplicates(updated[finishedIndex].text),
                };
                return updated;
              }
              return prev;
            });
          }
          
          // ✅ เมื่ออยู่ในโหมดคำสั่ง ให้เรียก handleRead_ai หลัง 1.5 วินาที (จำลองการกดปุ่ม)
          if (lastMessageType === "คำสั่ง") {
            console.log("🤖 Command mode detected: simulating 'Data from AI' button click in 1.5 seconds...");
            console.log("📊 Current lastMessageType:", lastMessageType);
            
            if (typeof handleRead_ai === 'function' && typeof handleButtonClick === 'function') {
              setTimeout(() => {
                try {
                  console.log("🚀 Simulating button click: Data from AI");
                  // จำลองการกดปุ่ม "Data from AI" แบบเดียวกับใน Page_all1.jsx
                  handleButtonClick('ai', handleRead_ai);
                  console.log("✅ Button click simulation completed successfully");
                } catch (error) {
                  console.error("❌ Error simulating button click:", error);
                }
              }, 1500);
            } else {
              console.error("❌ Required functions not available:", {
                handleRead_ai: typeof handleRead_ai,
                handleButtonClick: typeof handleButtonClick
              });
            }
          } else {
            console.log("ℹ️ Not in command mode. Current messageType:", lastMessageType);
          }
        } else if (j.event === "error") {
          addMessage("bot", "ERROR: " + (j.detail || "unknown"));
          streamingRef.current = null;
        } else {
          updateStreaming(typeof j === "string" ? j : ev.data);
        }
      } catch {
        updateStreaming(ev.data);
      }
    };
  }, [wsUrl, addMessage, updateStreaming, updateWSStatus, lastMessageType, handleRead_ai]);

  // ===== WebSocket Effect =====
  useEffect(() => {
    shouldReconnectRef.current = true;
    connectWS();
    
    return () => {
      shouldReconnectRef.current = false;
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      if (wsRef.current) {
        if (wsRef.current.readyState === WebSocket.OPEN ||
            wsRef.current.readyState === WebSocket.CONNECTING) {
          wsRef.current.close();
        }
      }
    };
  }, [connectWS]);

  // ===== Send Message (แก้ไขเพื่อป้องกันข้อความซ้ำ) =====
  const sendMessage = useCallback(
    async (rawText, attachments = [], messageType = "คำถาม") => {
      const message = typeof rawText === "string" ? rawText.trim() : "";
      if (!message && attachments.length === 0) return;

      // เก็บประเภทข้อความสำหรับใช้งานหลัง WebSocket ตอบกลับ
      setLastMessageType(messageType);
      console.log("📝 Message type set to:", messageType);

      // แสดงข้อความฝั่งผู้ใช้
      const attachmentNote = attachments.length 
        ? `[ไฟล์แนบ ${attachments.length} ไฟล์]` 
        : "";
      const userDisplay = attachmentNote 
        ? [message, attachmentNote].filter(Boolean).join("\n") 
        : message;
      
      if (userDisplay) {
        addMessage("user", userDisplay);
      }

      const payload = {
        message,
        model,
        temperature: TEMPERATURE_DEFAULT,
        condition_url: CONDITION_URL_DEFAULT,
        message_type: messageType, // เพิ่มประเภทข้อความ
        attachments: attachments.map((a) => ({
          name: a.name,
          type: a.type,
          size: a.size,
          base64: a.base64,
        })),
      };

      // WebSocket
      if (isConnected && wsRef.current?.readyState === WebSocket.OPEN) {
        // ใช้ functional update เพื่อป้องกัน race condition
        setChatLog(prev => {
          streamingRef.current = prev.length;
          chunkCountRef.current = 0;
          return [...prev, { who: "bot", text: "", id: Date.now() + Math.random() }];
        });
        wsRef.current.send(JSON.stringify(payload));
        return;
      }

      // HTTP Fallback
      try {
        const res = await fetch(apiUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        addMessage("bot", data.reply || "(No content)");
      } catch (e) {
        console.error('[HTTP] Error:', e);
        addMessage("bot", "HTTP ERROR: การเชื่อมต่อล้มเหลว โปรดลองใหม่อีกครั้ง");
      }
    },
    [addMessage, apiUrl, isConnected, model, setLastMessageType]
  );

  return (
    <div className="wrap">
      {/* ปุ่มด้านบนขวา */}
      {!chatOpen && !drawerOpen && (
        <div className="top-actions">
          <button 
            className="chat-btn" 
            onClick={() => setChatOpen(true)}
            title="เปิดแชท"
          >
            💬 แชท
          </button>

          <button 
            className="gear-btn" 
            onClick={() => setDrawerOpen(true)}
            title="เปิดการตั้งค่า"
          >
            ⚙ ตั้งค่า
          </button>
        </div>
      )}  

      {/* Drawer แชท */}
      <Chat_Drawer
        chatOpen={chatOpen}
        setChatOpen={setChatOpen}
        chatLog={chatLog}
        status={status}
        isConnected={isConnected}
        sendMessage={sendMessage}
        setChatLog={setChatLog}
      />

      {/* Drawer ขวา */}
      <Drawer
        drawerOpen={drawerOpen}
        setDrawerOpen={setDrawerOpen}
        wsUrl={wsUrl} 
        setWsUrl={setWsUrl}
        apiUrl={apiUrl} 
        setApiUrl={setApiUrl}
        model={model} 
        setModel={setModel}
        CONDITION_URL_DEFAULT={CONDITION_URL_DEFAULT}
      />

      {/* Mini Composer + FAB */}
      <MiniComposer 
        miniOpen={miniOpen} 
        setMiniOpen={setMiniOpen} 
        sendMessage={sendMessage}
        chatLog={chatLog}
        setChatOpen={setChatOpen}
      />
    </div>
  );
}

export default App_main;