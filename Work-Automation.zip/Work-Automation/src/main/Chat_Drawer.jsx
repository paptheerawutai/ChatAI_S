import React, { useState, useEffect, useRef } from "react";

function Chat_Drawer({
  chatOpen,
  setChatOpen,
  chatLog,
  status,
  sendMessage,
  setChatLog,
}) {
  const [text, setText] = useState("");
  const [messageType, setMessageType] = useState("คำถาม"); // "คำถาม" หรือ "คำสั่ง"
  const chatEndRef = useRef(null);

  const handleSend = () => {
    const trimmed = text.trim();
    if (!trimmed) return;
    // ส่งข้อความพร้อมกับประเภทข้อความ
    sendMessage(trimmed, [], messageType);
    setText("");
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      handleSend();
    }
  };

  // Auto-scroll to bottom when new messages arrive
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (chatOpen) {
      scrollToBottom();
    }
  }, [chatLog, chatOpen]);

  return (
    <>
      <div
        className={`drawer-overlay ${chatOpen ? "open" : ""}`}
        onClick={() => setChatOpen(false)}
      />

      <aside className={`drawer chat-drawer ${chatOpen ? "open" : ""}`}>
        <div className="drawer-header">
          <div className="header-content">
            <div className="drawer-title">โต้ตอบ</div>  
            
            {/* Minimal Message Type Selector */}
            <div className="message-type-minimal">
              <button
                className={`type-btn ${messageType === "คำถาม" ? "active" : ""}`}
                onClick={() => setMessageType("คำถาม")}
                title="คำถาม"
              >
                ❓
              </button>
              <button
                className={`type-btn ${messageType === "คำสั่ง" ? "active" : ""}`}
                onClick={() => setMessageType("คำสั่ง")}
                title="คำสั่ง"
              >
                ⚡
              </button>
            </div>
          </div>
          
          <button
            className="btn secondary close-btn"
            onClick={() => setChatOpen(false)}
            aria-label="ปิดแชท"
          >
            ✕
          </button>
        </div>

        <div className="drawer-body">
          <div className="chat">
            {chatLog.map((msg) => (
              <div key={msg.id} className={`bubble ${msg.who}`}>
                {msg.text}
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>



          <textarea
            value={text}
            onChange={(event) => setText(event.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={messageType === "คำถาม" 
              ? "พิมพ์คำถาม แล้วกด Ctrl/Cmd + Enter เพื่อส่ง" 
              : "พิมพ์คำสั่ง แล้วกด Ctrl/Cmd + Enter เพื่อส่ง"
            }
          />

          <div className="chat-actions row">
            <button className="btn send" onClick={handleSend}>
              🚀 Send
            </button>
            <button className="btn clear" onClick={() => setChatLog([])}>
              🗑 Clear
            </button>
            <span className={`status ${status.includes("connected") ? "connected" : ""}`}>
              {status}
            </span>
          </div>
        </div>
      </aside>
    </>
  );
}

export default Chat_Drawer;