import React, { useState, useRef, useEffect } from "react";
import "./MiniComposer.css";

function MiniComposer({ miniOpen, setMiniOpen, sendMessage, chatLog, setChatOpen }) {
  const [selectedAction, setSelectedAction] = useState("");
  const [customText, setCustomText] = useState("");
  const [showCustomInput, setShowCustomInput] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const miniInputRef = useRef(null);
  const fileInputRef = useRef(null);

  // Quick Actions สำหรับส่งข้อความ
  const quickActions = [
    { id: 'check', text: 'ขอ Condition', color: '#22c55e', messageType: 'คำถาม' },
    { id: 'error', text: 'เจอปัญหางาน แหว่ง', color: '#f59e0b', messageType: 'คำสั่ง' },
    { id: 'update', text: 'เจอปัญหางาน มีครีบ', color: '#3b82f6', messageType: 'คำสั่ง' },
    { id: 'config', text: 'เจอปัญหางาน เป็นจุดดำ', color: '#8b5cf6', messageType: 'คำสั่ง' },
    { id: 'help', text: 'เจอปัญหางาน งานรั้งขาว', color: '#06b6d4', messageType: 'คำสั่ง' },
    { id: 'custom', text: 'ข้อความกำหนดเอง', color: '#ef4444', messageType: 'คำถาม' }
  ];

  // Auto-focus เมื่อเปิด mini
  useEffect(() => {
    if (miniOpen && showCustomInput && miniInputRef.current) {
      setTimeout(() => miniInputRef.current?.focus(), 100);
    }
  }, [miniOpen, showCustomInput]);

  // แปลงไฟล์เป็น base64
  const fileToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result).split(',')[1] || '');
      fr.onerror = reject;
      fr.readAsDataURL(file);
    });
  };

  // จัดการไฟล์ที่แนบ
  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files || []);
    const newAttachments = [];
    
    for (const f of files) {
      const total = attachments.reduce((s, a) => s + (a.size || 0), 0) + f.size;
      if (total > 5 * 1024 * 1024) {
        alert('ไฟล์รวมเกิน 5MB');
        continue;
      }
      const base64 = await fileToBase64(f);
      newAttachments.push({ 
        name: f.name, 
        type: f.type, 
        size: f.size, 
        base64 
      });
    }
    
    setAttachments(prev => [...prev, ...newAttachments]);
    e.target.value = '';
  };

  // ลบไฟล์
  const removeAttachment = (idx) => {
    setAttachments(prev => prev.filter((_, i) => i !== idx));
  };

  // เลือก Quick Action
  const handleActionSelect = (action) => {
    setSelectedAction(action.id);
    if (action.id === 'custom') {
      setShowCustomInput(true);
    } else {
      setShowCustomInput(false);
      setCustomText("");
    }
  };

  // ส่งข้อความ
  const handleSend = async () => {
    let textToSend = "";
    let messageType = "คำถาม"; // default
    
    if (selectedAction === 'custom') {
      textToSend = customText.trim();
      // สำหรับ custom message ใช้ default messageType
    } else {
      const action = quickActions.find(a => a.id === selectedAction);
      if (action) {
        textToSend = action.text;
        messageType = action.messageType || "คำถาม"; // ใช้ messageType จาก action
      }
    }
    
    if (!textToSend && attachments.length === 0) {
      // Flash animation
      const composer = document.querySelector('.mini-composer');
      if (composer) {
        composer.classList.add('flash');
        setTimeout(() => composer?.classList.remove('flash'), 1000);
      }
      return;
    }

    console.log("🚀 MiniComposer sending message:", { textToSend, messageType });
    await sendMessage(textToSend, attachments, messageType);
    
    // Reset form state
    setSelectedAction("");
    setCustomText("");
    setShowCustomInput(false);
    setAttachments([]);
    
    // ปิด MiniComposer และเปิด Chat_Drawer
    setMiniOpen(false);
    if (setChatOpen) {
      setChatOpen(true);
    }
  };

  // ดึงข้อความล่าสุดมาแก้
  const handlePickLatest = () => {
    if (!chatLog || chatLog.length === 0) return;
    
    const userMessages = chatLog.filter(m => m.who === 'user');
    const lastMsg = userMessages[userMessages.length - 1];
    
    if (lastMsg && lastMsg.text) {
      // กรองข้อความไฟล์แนบออก
      const text = lastMsg.text.split('\n[ไฟล์แนบ')[0];
      setCustomText(text);
      setSelectedAction('custom');
      setShowCustomInput(true);
      setTimeout(() => miniInputRef.current?.focus(), 100);
    }
  };

  // Keyboard shortcuts
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    } else if (e.key === 'Escape') {
      setMiniOpen(false);
    }
  };

  return (
    <>
      {/* Background Overlay */}
      <div 
        className={`mini-overlay ${miniOpen ? 'show' : ''}`}
        onClick={() => setMiniOpen(false)}
      />

      {/* FAB Button */}
      <button 
        className="fab" 
        onClick={() => {
          if (!miniOpen) setMiniOpen(true);
          else if (showCustomInput && miniInputRef.current) miniInputRef.current?.focus();
        }}
        title="เปิด/โฟกัส มินิแชท"
      >
        <svg viewBox="0 0 24 24" fill="none">
          <path d="M7 9h10M7 13h6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
          <path d="M5 17v2.8a.8.8 0 0 0 1.27.65L9.5 18H18a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H6a3 3 0 0 0-3 3v8a2 2 0 0 0 2 2h0Z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round"/>
        </svg>
      </button>

      {/* Mini Composer */}
      <div className={`mini-composer ${miniOpen ? "open" : ""}`}>
        <div className="mini-header">
          <div className="mini-title">
            <span className="mini-icon">💬</span>
            Quick Actions
          </div>
          <div className="mini-actions">
            {/* <button 
              className="mini-btn secondary" 
              onClick={handlePickLatest}
              title="ดึงข้อความล่าสุดมาแก้ไข"
            >
              📝 แก้ไข
            </button> */}
            <button className="mini-btn close" onClick={() => setMiniOpen(false)}>
              ✕
            </button>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="quick-actions">
          {quickActions.map((action) => (
            <button
              key={action.id}
              className={`action-btn ${selectedAction === action.id ? 'selected' : ''} ${action.messageType === 'คำสั่ง' ? 'command-mode' : ''}`}
              onClick={() => handleActionSelect(action)}
              style={{ '--action-color': action.color }}
              title={`${action.text} (${action.messageType})`}
            >
              <span className="action-icon">
                {action.messageType === 'คำสั่ง' ? '⚡' : '❓'}
              </span>
              <span className="action-text">{action.text}</span>
            </button>
          ))}
        </div>

        {/* Custom Input (แสดงเมื่อเลือก custom) */}
        {showCustomInput && (
          <div className="custom-input-section">
            <input
              ref={miniInputRef}
              type="text"
              className="custom-input"
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="พิมพ์ข้อความที่ต้องการส่ง..."
            />
          </div>
        )}

        {/* Action Bar */}
        <div className="action-bar">
          <button 
            className="attach-btn"
            onClick={() => fileInputRef.current?.click()}
          >
            📎 <span>แนบไฟล์</span>
          </button>
          
          <button 
            className={`send-btn ${selectedAction ? 'active' : ''}`}
            onClick={handleSend}
            disabled={!selectedAction}
          >
            <span className="send-icon">🚀</span>
            <span>ส่งข้อความ</span>
          </button>
        </div>

        {/* Attachment List */}
        {attachments.length > 0 && (
          <div className="attach-list">
            <div className="attach-header">
              <span>📁 ไฟล์แนบ ({attachments.length})</span>
            </div>
            {attachments.map((a, idx) => (
              <div key={idx} className="attach-item">
                {a.type.startsWith('image/') ? (
                  <img 
                    className="attach-thumb" 
                    src={`data:${a.type};base64,${a.base64}`}
                    alt={a.name}
                  />
                ) : (
                  <div className="attach-thumb file-thumb">
                    <span>{a.type.split('/')[1]?.toUpperCase() || 'FILE'}</span>
                  </div>
                )}
                <div className="attach-meta">
                  <strong>{a.name}</strong>
                  <span>{(a.size / 1024).toFixed(1)} KB</span>
                </div>
                <button 
                  className="attach-remove" 
                  onClick={() => removeAttachment(idx)}
                  title="ลบไฟล์"
                >
                  🗑️
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Hidden File Input */}
        <input 
          ref={fileInputRef}
          type="file" 
          multiple 
          hidden 
          onChange={handleFileChange}
        />
      </div>
    </>
  );
}

export default MiniComposer;