
import React, { useState } from "react";
import styles from "./css/CORESETTING.module.css";

const header = ["IN-H", "IN-L", "OUT-H", "OUT-L", "IN-H", "IN-L", "OUT-H", "OUT-L"];
const rows = ["PRESSURE", "SPEED", "TIME", "COUNTER", "POSITION", "FUNCTION"];

export default function CORESETTING({ onDataChange }) {
  // สร้าง state สำหรับเก็บค่าจาก input (object per header)
  const [form, setForm] = useState(
    rows.reduce((acc, row) => ({
      ...acc,
      [row]: header.reduce((hAcc, h) => ({ ...hAcc, [h]: "" }), {})
    }), {})
  );

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (rowKey, idx, value) => {
    const key = header[idx];
    const newForm = {
      ...form,
      [rowKey]: {
        ...form[rowKey],
        [key]: value
      }
    };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.sectionTitle} style={{ textAlign: 'left' }}>
        <span style={{ fontWeight: 'bold' }}>CORE SETTING</span>
      </div>
      <table className={styles.table}>
        <colgroup>
          <col />
          {header.map((_, i) => <col key={i} />)}
          <col />
        </colgroup>
        <thead>
          <tr>
            <th></th>
            {header.map((h, i) => (
              <th key={i} className={styles.head}>{h}</th>
            ))}
            <th className={styles.tolerance}></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rIdx) => (
            <tr key={row}>
              <td className={rIdx === 0 ? styles.head1 : styles.head}>{row}</td>
              {header.map((h, idx) => (
                <td key={h + idx} className={rIdx === 0 || row === "COUNTER" ? undefined : styles.yellow}>
                  <input
                    type="text"
                    style={{ width: '100%' }}
                    value={form[row][h]}
                    onChange={e => handleInputChange(row, idx, e.target.value)}
                  />
                </td>
              ))}
              <td className={styles.tolerance} style={{ verticalAlign: 'middle' }}>
                {row === "PRESSURE" && <>±10 kg/cm<sup>2</sup></>}
                {row === "SPEED" && <>±10 mm/s</>}
                {row === "TIME" && <>±5 s</>}
                {row === "POSITION" && <>±10 mm.</>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
