
import React, { useState, useEffect } from "react";
import styles from "./css/Hotrunner.module.css";

const header = ["Z1", "Z2", "Z3", "Z4", "Z5", "Z6", "Z7", "Z8"];

export default function Hotrunner({ onDataChange, initialData }) {
  // สร้าง state สำหรับเก็บค่าจาก input (object per header)
  const [form, setForm] = useState({
    A: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
    B: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {})
  });
  // state สำหรับเก็บ field ที่ต้องแสดงสีฟ้า (local highlight)
  const [localFlash, setLocalFlash] = useState([]);
  // state สำหรับเก็บค่าล่าสุดเพื่อเปรียบเทียบ
  const [lastData, setLastData] = useState({});

  // รับข้อมูลจาก initialData และตรวจสอบการเปลี่ยนแปลงแต่ละช่อง
  useEffect(() => {
    if (initialData) {
      // ตรวจสอบการเปลี่ยนแปลงก่อนอัปเดต form
      if (Object.keys(lastData).length > 0) {
        const changedCells = [];
        
        Object.keys(initialData).forEach(section => {
          if (initialData[section] && typeof initialData[section] === 'object') {
            Object.keys(initialData[section]).forEach(key => {
              const newValue = initialData[section][key];
              const oldValue = lastData[section]?.[key];
              
              // เปรียบเทียบค่าแต่ละช่อง ถ้าต่างกันให้เพิ่มเข้า changedCells
              if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
                changedCells.push(`${section}.${key}`);
              }
            });
          }
        });

        if (changedCells.length > 0) {
          console.log('Hotrunner changed cells:', changedCells);
          setLocalFlash(changedCells);
          
          // ลบสีหลังจาก 5 วินาที
          setTimeout(() => {
            setLocalFlash([]);
          }, 30000);
        }
      }
      
      // อัปเดต form และ lastData
      setForm({
        A: initialData.A ? initialData.A : header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
        B: initialData.B ? initialData.B : header.reduce((acc, h) => ({ ...acc, [h]: "" }), {})
      });
      setLastData(JSON.parse(JSON.stringify(initialData)));
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (rowKey, idx, value) => {
    const key = header[idx];
    const newForm = {
      ...form,
      [rowKey]: {
        ...form[rowKey],
        [key]: value
      }
    };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.sectionTitle} style={{ textAlign: 'center' }}>
        <span style={{ fontWeight: 'bold' }}>Hot Runner ( ℃ )</span>
      </div>
      <table className={styles.table}>
        <colgroup>
          <col />
          {header.map((_, i) => <col key={i} />)}
          <col />
        </colgroup>
        <thead>
          <tr>
            <th></th>
            {header.map(h => (
              <th key={h} className={styles.head}>{h}</th>
            ))}
            <th className={styles.tolerance}></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className={styles.head}>A</td>
            {header.map((h, idx) => {
              // ตรวจสอบว่าช่องนี้ควรเปลี่ยนสีหรือไม่
              const cellKey = `A.${h}`;
              const shouldHighlight = localFlash.includes(cellKey);
              
              return (
                <td key={h} className={styles.yellow} style={{
                  backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                  border: shouldHighlight ? '2px solid #0066cc' : '',
                  transition: 'all 0.3s ease'
                }}>
                  <input
                    type="text"
                    // style={{ 
                    //   width: '60px',
                    //   background: shouldHighlight ? '#cce6ff' : 'transparent',
                    //   outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                    //   color: shouldHighlight ? '#003366' : 'inherit',
                    //   transition: 'all 0.3s ease'
                    // }}
                    value={form.A[h]}
                    onChange={e => handleInputChange("A", idx, e.target.value)}
                  />
                </td>
              );
            })}
            <td className={styles.tolerance} rowSpan={2} style={{ fontWeight: 'bold', fontSize: '18px', verticalAlign: 'middle' }}>±10 ℃</td>
          </tr>
          <tr>
            <td className={styles.head}>B</td>
            {header.map((h, idx) => {
              // ตรวจสอบว่าช่องนี้ควรเปลี่ยนสีหรือไม่
              const cellKey = `B.${h}`;
              const shouldHighlight = localFlash.includes(cellKey);
              
              return (
                <td key={h} className={styles.yellow} style={{
                  backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                  border: shouldHighlight ? '2px solid #0066cc' : '',
                  transition: 'all 0.3s ease'
                }}>
                  <input
                    type="text"
                    // style={{ 
                    //   width: '60px',
                    //   background: shouldHighlight ? '#cce6ff' : 'transparent',
                    //   outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                    //   color: shouldHighlight ? '#003366' : 'inherit',
                    //   transition: 'all 0.3s ease'
                    // }}
                    value={form.B[h]}
                    onChange={e => handleInputChange("B", idx, e.target.value)}
                  />
                </td>
              );
            })}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
