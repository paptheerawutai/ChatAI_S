
// import React, { useState } from 'react';
// import tableStyles from './css/TableCard.module.css';
// import EJECTOR from './EJECTOR';
// import MOLDCLOSE from './MOLDCLOSE';
// import MOLDOPEN from './MOLDOPEN';
// import TEMP from './TEMP';
// import Hotrunner from './Hotrunner';
// import ValveGate from './ValveGate';
// import CORESETTING from './CORESETTING';
// import LAB from './LAB';
// import INJECTIONActual from './INJECTIONActual';
// import SCREW_ROTATE from './SCREW_ROTATE';
// import HOLDING_INJECTION from './HOLDING_INJECTION';
// import axios from 'axios';

// function Page_all() {
//   // State สำหรับเก็บข้อมูลจากทุก component
//   const [allData, setAllData] = useState({
//     injection: {},
//     temperature_setting: {},
//     hotrunner: {},
//     holding_injection: {},
//     screw_rotate: {},
//     mold_close: {},
//     mold_open: {},
//     ejector: {},
//     core_setting: {},
//     valve_gate_sec: {},
//     lubrication: {}
//   });

//   // โหลดข้อมูลจาก API
//   const handleRead = async () => {
//     try {
//       // const res = await axios.get('http://localhost:5005/4m/condition_standard');
//       // const res = await axios.get('http://172.20.10.3:8000/signal?api_key=demo-key-001&machine_no=MC12&part_code=RK25A294G06-F');
//       const res = await axios.get('http://172.20.10.3:8000/signal-standard?api_key=demo-key-001&machine_no=MC12&part_code=RK25A294G06-F', {
//       });
//       if (res.data && res.data.condition_standard) {
//         setAllData(res.data.condition_standard);
//         alert('✅ อ่านข้อมูลสำเร็จ');
//       } else {
//         alert('⚠ ไม่พบข้อมูลใน API');
//       }
//     } catch (err) {
//       console.error(err);
//       alert('⚠ เกิดข้อผิดพลาด: ' + err.message);
//     }
//   };

//   // Callback สำหรับรับข้อมูลจากแต่ละ component
//   const handleDataChange = (key, value) => {
//     setAllData(prev => ({ ...prev, [key]: value }));
//   };

//   // ส่งข้อมูลทั้งหมดออก
//   const handleSend = async () => {
//     try {
//       const res = await axios.post('http://172.20.10.3:8000/v1/conditions', allData, {
//         headers: {
//           'X-API-Key': 'demo-key-001',
//           'Idempotency-Key': 'abc-123-unique',
//           'Content-Type': 'application/json5'
//         }
//       });
//       // const res = await axios.post('http://localhost:5005/4m/condition_standard', allData);
//       alert('✅ ส่งข้อมูลสำเร็จ: ' + JSON.stringify(res.data));
//     } catch (err) {
//       console.error(err);
//       alert('⚠ เกิดข้อผิดพลาด: ' + err.message);
//     }
//   };

//   return (
//     <div className={tableStyles.gridContainer} style={{ marginTop: '20px' }}>
      
//       <div className={tableStyles.card1}>
//         <INJECTIONActual onDataChange={data => handleDataChange('injection', data)} initialData={allData.injection} />
//         {/* LAB ไม่ต้อง initialData เพราะไม่มีข้อมูลใน API ตัวอย่าง */}
//         <div style={{ textAlign: 'center', marginBottom: '16px' }}>
//         <button
//           style={{
//             background: '#43a047',
//             color: '#fff',
//             border: 'none',
//             borderRadius: '8px',
//             padding: '12px 32px',
//             fontSize: '18px',
//             fontWeight: 'bold',
//             cursor: 'pointer',
//             boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
//             transition: 'background 0.2s',
//             marginRight: '16px'
//           }}
//           onMouseOver={e => (e.target.style.background = '#388e3c')}
//           onMouseOut={e => (e.target.style.background = '#43a047')}
//           onClick={handleRead}
//         >
//           อ่านข้อมูลจาก API
//         </button>
//         <button
//           style={{
//             background: '#1976d2',
//             color: '#fff',
//             border: 'none',
//             borderRadius: '8px',
//             padding: '12px 32px',
//             fontSize: '18px',
//             fontWeight: 'bold',
//             cursor: 'pointer',
//             boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
//             transition: 'background 0.2s'
//           }}
//           onMouseOver={e => (e.target.style.background = '#1565c0')}
//           onMouseOut={e => (e.target.style.background = '#1976d2')}
//           onClick={handleSend}
//         >
//           ส่งข้อมูลทั้งหมด
//         </button>
//       </div>
//       </div>
//       <div className={tableStyles.card2}>
//         <div className={tableStyles.rf1}>
//           <HOLDING_INJECTION onDataChange={data => handleDataChange('holding_injection', data)} initialData={allData.holding_injection} />
//         </div>
//         <div className={tableStyles.rfi}>
//           <SCREW_ROTATE onDataChange={data => handleDataChange('screw_rotate', data)} initialData={allData.screw_rotate} />
//         </div>
//       </div>
//       <div className={tableStyles.card4}
//         style={{
//           display: 'grid',
//           gridTemplateColumns: 'repeat(2, 1fr)',
//           gap: '6px'
//         }}
//       >
//         <div className={tableStyles.rf1}>
//           <TEMP onDataChange={data => handleDataChange('temperature_setting', data)} initialData={allData.temperature_setting} />
//           <Hotrunner onDataChange={data => handleDataChange('hotrunner', data)} initialData={allData.hotrunner} />
//           <ValveGate onDataChange={data => handleDataChange('valve_gate_sec', data)} initialData={allData.valve_gate_sec} />
//           <CORESETTING onDataChange={data => handleDataChange('core_setting', data)} initialData={allData.core_setting} />
//         </div>
//         <div className={tableStyles.rf1} style={{ marginLeft: '50px' }}>
//           <EJECTOR onDataChange={data => handleDataChange('ejector', data)} initialData={allData.ejector} />
//           <MOLDCLOSE onDataChange={data => handleDataChange('mold_close', data)} initialData={allData.mold_close} />
//           <MOLDOPEN onDataChange={data => handleDataChange('mold_open', data)} initialData={allData.mold_open} />
//           <LAB onDataChange={data => handleDataChange('lubrication', data)} initialData={allData.lubrication} />
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Page_all;

import React, { useState } from 'react';
import tableStyles from './css/TableCard.module.css';
import EJECTOR from './EJECTOR';
import MOLDCLOSE from './MOLDCLOSE';
import MOLDOPEN from './MOLDOPEN';
import TEMP from './TEMP';
import Hotrunner from './Hotrunner';
import ValveGate from './ValveGate';
import CORESETTING from './CORESETTING';
import LAB from './LAB';
import INJECTIONActual from './INJECTIONActual';
import SCREW_ROTATE from './SCREW_ROTATE';
import HOLDING_INJECTION from './HOLDING_INJECTION';
import axios from 'axios';
import ChatLLM from './ChatLLM';

function Page_all() {
  // State สำหรับเก็บข้อมูลจากทุก component
  const [allData, setAllData] = useState({
    injection: {},
    temperature_setting: {},
    hotrunner: {},
    holding_injection: {},
    screw_rotate: {},
    mold_close: {},
    mold_open: {},
    ejector: {},
    core_setting: {},
    valve_gate_sec: {},
    lubrication: {}
  });

  // โหลดข้อมูลจาก API
  const handleRead = async () => {
    try {
      // const res = await axios.get('http://localhost:5005/4m/condition_standard777');
      const res = await axios.get('http://172.20.10.2:5005/4m/condition_all');
      
      // const res = await axios.get('http://172.20.10.3:8000/signal?api_key=demo-key-001&machine_no=MC12&part_code=RK25A294G06-F');

      if (res.data && res.data.condition_standard) {
        setAllData(res.data.condition_standard);
        alert('✅ ส่งข้อมูลสำเร็จแล้ว ลองตรวจสอบดู');
      } else {
        alert('⚠ ไม่พบข้อมูลใน API');
      }
    } catch (err) {
      console.error(err);
      alert('⚠ เกิดข้อผิดพลาด: ' + err.message);
    }
  };

  // Callback สำหรับรับข้อมูลจากแต่ละ component
  const handleDataChange = (key, value) => {
    setAllData(prev => ({ ...prev, [key]: value }));
  };
  
  // ส่งข้อมูลทั้งหมดออก
  const handleSend = async () => {
    try {
      // const res = await axios.post('http://172.20.10.3:8000/v1/conditions', allData);
      const res = await axios.post('http://172.20.10.2:5005/4m/condition_standard', allData);
      // const res = await axios.post('http://172.20.10.3:8000/v1/conditions', allData, {
      //   headers: {
      //     'X-API-Key': 'demo-key-001',
      //     'Idempotency-Key': 'abc-123-unique',
      //     'Content-Type': 'application/json5'
      //   }
      // });

      console.log(res.data);
      alert('✅ ส่งข้อมูลสำเร็จ: ' + JSON.stringify(res.data));
    } catch (err) {
      console.error(err);
      alert('⚠ เกิดข้อผิดพลาด: ' + err.message);
    }
  };

  return (
    <div className={tableStyles.gridContainer} style={{ marginTop: '20px' }}>
      
      
      <div className={tableStyles.card1}>
        <INJECTIONActual onDataChange={data => handleDataChange('injection', data)} initialData={allData.injection} />
        {/* LAB ไม่ต้อง initialData เพราะไม่มีข้อมูลใน API ตัวอย่าง */}
        <div style={{ textAlign: 'center', marginBottom: '16px' }}>
        <button
          style={{
            background: '#43a047',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            padding: '12px 32px',
            fontSize: '18px',
            fontWeight: 'bold',
            cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
            transition: 'background 0.2s',
            marginRight: '16px'
          }}
          onMouseOver={e => (e.target.style.background = '#388e3c')}
          onMouseOut={e => (e.target.style.background = '#43a047')}
          onClick={handleRead}
        >
          Export
        </button>
        <button
          style={{
            background: '#1976d2',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            padding: '12px 32px',
            fontSize: '18px',
            fontWeight: 'bold',
            cursor: 'pointer',
            boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
            transition: 'background 0.2s'
          }}
          onMouseOver={e => (e.target.style.background = '#1565c0')}
          onMouseOut={e => (e.target.style.background = '#1976d2')}
          onClick={handleSend}
        >
          ส่งข้อมูลทั้งหมด
        </button>
      </div>
      </div>
      <div className={tableStyles.card2}>
        <div className={tableStyles.rf1}>
          <HOLDING_INJECTION onDataChange={data => handleDataChange('holding_injection', data)} initialData={allData.holding_injection} />
        </div>
        <div className={tableStyles.rfi}>
          <SCREW_ROTATE onDataChange={data => handleDataChange('screw_rotate', data)} initialData={allData.screw_rotate} />
        </div>
      </div>
      <div className={tableStyles.card4}
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(2, 1fr)',
          gap: '6px'
        }}
      >
        <div className={tableStyles.rf1}>
          <TEMP onDataChange={data => handleDataChange('temperature_setting', data)} initialData={allData.temperature_setting} />
          <Hotrunner onDataChange={data => handleDataChange('hotrunner', data)} initialData={allData.hotrunner} />
          <ValveGate onDataChange={data => handleDataChange('valve_gate_sec', data)} initialData={allData.valve_gate_sec} />
          <CORESETTING onDataChange={data => handleDataChange('core_setting', data)} initialData={allData.core_setting} />
        </div>
        <div className={tableStyles.rf1} style={{ marginLeft: '50px' }}>
          <EJECTOR onDataChange={data => handleDataChange('ejector', data)} initialData={allData.ejector} />
          <MOLDCLOSE onDataChange={data => handleDataChange('mold_close', data)} initialData={allData.mold_close} />
          <MOLDOPEN onDataChange={data => handleDataChange('mold_open', data)} initialData={allData.mold_open} />
          <LAB onDataChange={data => handleDataChange('lubrication', data)} initialData={allData.lubrication} />
        </div>
      </div>
    </div>
  );
}

export default Page_all;