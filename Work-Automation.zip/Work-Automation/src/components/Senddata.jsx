// import React from "react";
// import axios from "axios";

// const data = {
//   condition_standard: {
//     general_info: {
//       machine_no: "12",
//       customer: "SHARP",
//       part_name: "FT-C45B",
//       part_code: "4Y0K-A97L2CPFA",
//       machine_size_ton: 450,
//       date: "29/08/18",
//       mat_name: "CPL19705",
//       pcs_weight: { std: 6.8, actual: 6.15 },
//       runner_weight: "STD",
//       cavity_set: 1,
//       hopper_dryer_temp: "+15°C",
//       hopper_dryer_time: "1 hr"
//     },
//     injection: {
//       inj_time_sec: { std: 13, tol: "±3" },
//       cooling_time_sec: { std: 23, tol: "±5" },
//       cycle_time_sec: { std: 55, tol: "±5" },
//       cushion_mm: { std: 15, tol: "±5" },
//       scw_monitor_sec: { std: 24, tol: "±10" },
//       bp_pressure: { std: 15, tol: "±1 kg/s²" },
//       clamping_force: { std: 100, tol: "±5 kg/cm²" },
//       oil_temp_c: { std: 40, tol: "±3°C" }
//     },
//     temperature_setting: {
//       NH: 240,
//       H1: 225,
//       H2: 200,
//       H3: 180,
//       H4: 180,
//       H5: 180,
//       H6: 150,
//       hot_runner: {
//         A: [220, 220],
//         Z1: 220,
//         Z2: 220
//       }
//     },
//     holding_injection: {
//       pressure: {
//         HP4: 65,
//         HP3: 75,
//         HP2: 75,
//         HP1: 75,
//         "5TH": 65,
//         "4TH": 50,
//         "3RD": 55,
//         "2ND": 60,
//         "1ST": 30
//       },
//       speed: { HP4: 20, HP3: 48, HP2: 50, HP1: 55, others: "..." },
//       time_sec: 5,
//       position_mm: [32, 45, 80, 125, 175]
//     },
//     screw_rotate: {
//       pressure: { SCW1: 140, SCW2: 140, SCW3: 140, POSI_BACK: 95 },
//       speed: { SCW1: 98, SCW2: 98, SCW3: 98, POSI_BACK: 45 },
//       position: { POSI_BACK: "170+5.5" }
//     },
//     mold_close: {
//       pressure: { HS: 95, LS: 95, LP: 140, HP1: 120, HP2: 120 },
//       speed: { HS: 95, LS: 95, LP: 100, HP1: 100, HP2: 100 },
//       position: { HS: 350, LS: 100, HP1: 100, HP2: 100 },
//       time_sec: { HS: 2.0, LS: 2.5 }
//     },
//     mold_open: {
//       pressure: { LS2: 80, MS: 70, HS: 80, LS1: 90 },
//       speed: { LS2: 40, MS: 75, HS: 80, LS1: 75 },
//       position: { LS2: 580, MS: 500, HS: 400, LS1: 150 }
//     },
//     ejector: {
//       pressure: { BWD: 55, FWDL: 65, FWDH: 60, HOLD: 36 },
//       speed: { BWD: 25, FWDL: 25, FWDH: 25, HOLD: 10 },
//       time_sec: 5,
//       position_mm: [5, 20, 85],
//       first_forward_posi_mm: 90
//     },
//     core_setting: { in_h: {}, in_l: {}, out_h: {}, out_l: {} },
//     valve_gate_sec: { Z1: 0, Z2: 0, Z3: 0, Z4: 0, Z5: 0, Z6: 0 },
//     lubrication: {
//       lub_count: 100,
//       lub_time: 100,
//       ejector_use: "SINGLE",
//       ejector_counter: 1
//     }
//   }
// };

// export default function Senddata() {
//   const sendData = async () => {
//     try {
//       const res = await axios.post("http://localhost:5005/4m/condition_standard", data);
//       alert("✅ ส่งข้อมูลสำเร็จ: " + JSON.stringify(res.data));
//     } catch (err) {
//       console.error(err);
//       alert("⚠ เกิดข้อผิดพลาด: " + err.message);
//     }
//   };

//   return (
//     <div style={{ display: "flex", justifyContent: "center", marginTop: "32px" }}>
//       <button
//         style={{
//           background: "#1976d2",
//           color: "#fff",
//           border: "none",
//           borderRadius: "8px",
//           padding: "12px 32px",
//           fontSize: "18px",
//           fontWeight: "bold",
//           cursor: "pointer",
//           boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
//           transition: "background 0.2s"
//         }}
//         onMouseOver={(e) => (e.target.style.background = "#1565c0")}
//         onMouseOut={(e) => (e.target.style.background = "#1976d2")}
//         onClick={sendData}
//       >
//         ส่งข้อมูล
//       </button>
//     </div>
//   );
// }


import React, { useState } from "react";
import axios from "axios";

export default function TableWithSend() {
  const [tableData, setTableData] = useState([
    { col1: "", col2: "" },
    { col1: "", col2: "" },
    // ...เพิ่มแถวตามต้องการ
  ]);

  const handleInputChange = (rowIdx, colName, value) => {
    const newData = [...tableData];
    newData[rowIdx][colName] = value;
    setTableData(newData);
  };

  const handleSend = async () => {
    try {
      // ส่งข้อมูลทั้งหมดไป backend
      const res = await axios.post("http://localhost:5005/4m/condition_standard", { tableData });
      alert("✅ ส่งข้อมูลสำเร็จ: " + JSON.stringify(res.data));
    } catch (err) {
      console.error(err);
      alert("⚠ เกิดข้อผิดพลาด: " + err.message);
    }
  };

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>คอลัมน์ 1</th>
            <th>คอลัมน์ 2</th>
          </tr>
        </thead>
        <tbody>
          {tableData.map((row, rowIdx) => (
            <tr key={rowIdx}>
              <td>
                <input
                  value={row.col1}
                  onChange={e => handleInputChange(rowIdx, "col1", e.target.value)}
                />
              </td>
              <td>
                <input
                  value={row.col2}
                  onChange={e => handleInputChange(rowIdx, "col2", e.target.value)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={handleSend}>ส่งข้อมูล</button>
    </div>
  );
}