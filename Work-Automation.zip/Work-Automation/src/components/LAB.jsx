
import React, { useState, useEffect } from 'react';
import styles from './css/LAB.module.css';

export default function LAB({ onDataChange, initialData }) {
  // สร้าง state สำหรับเก็บค่าจาก input
  const [form, setForm] = useState({
    lubCount: "",
    lubTime: "",
    ejectorUse: "",
    ejectorCounter: "",
    cavityTemp: "",
    coreTemp: "",
    temperature: ""
  });

  // รับข้อมูลจาก initialData เมื่อเปลี่ยน พร้อม fallback
  useEffect(() => {
    if (initialData) {
      setForm({
        lubCount: initialData.lubCount || "",
        lubTime: initialData.lubTime || "",
        ejectorUse: initialData.ejectorUse || "",
        ejectorCounter: initialData.ejectorCounter || "",
        cavityTemp: initialData.cavityTemp || "",
        coreTemp: initialData.coreTemp || "",
        temperature: initialData.temperature || ""
      });
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (key, value) => {
    const newForm = { ...form, [key]: value };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div className={styles.labWrap} style={{ marginTop: '20px' }}>
      {/* กล่อง 1: LUB */}
      <div className={styles.labBox}>
        <table className={styles.labTableVertical}>
          <tbody>
            <tr>
              <td className={styles.labLabel}>LUB. Count</td>
              <td className={styles.labCellYellow}>
                <input
                  type="text"
                  className={styles.labInput}
                  value={form.lubCount}
                  onChange={e => handleInputChange("lubCount", e.target.value)}
                />
              </td>
            </tr>
            <tr>
              <td className={styles.labLabel}>LUB. Time</td>
              <td className={styles.labCellYellow}>
                <input
                  type="text"
                  className={styles.labInput}
                  value={form.lubTime}
                  onChange={e => handleInputChange("lubTime", e.target.value)}
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      {/* กล่อง 2: EJECTOR */}
      <div className={styles.labBox}>
        <div className={styles.labTextRight}>
          <div>EJECTOR USE</div>
          <div style={{ marginTop: '32px' }}>EJECTOR COUNTER</div>
        </div>
        <table className={styles.labTableVertical} style={{ marginTop: '-64px', marginLeft: '120px' }}>
          <tbody>
            <tr>
              <td className={styles.labCellYellow} style={{ width: '120px' }}>
                <input
                  type="text"
                  className={styles.labInput}
                  value={form.ejectorUse}
                  onChange={e => handleInputChange("ejectorUse", e.target.value)}
                />
              </td>
            </tr>
            <tr>
              <td className={styles.labCellYellow} style={{ width: '120px' }}>
                <input
                  type="text"
                  className={styles.labInput}
                  value={form.ejectorCounter}
                  onChange={e => handleInputChange("ejectorCounter", e.target.value)}
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      {/* กล่อง 3: TEMP */}
      <div className={styles.labBox}>
        <table className={styles.labTableVertical}>
          <tbody>
            <tr>
              <td className={styles.tempLabel}>CAVITY TEMP (°C)</td>
              <td className={styles.tempCell}>
                <input
                  type="text"
                  className={styles.tempInput}
                  value={form.cavityTemp}
                  onChange={e => handleInputChange("cavityTemp", e.target.value)}
                />
              </td>
            </tr>
            <tr>
              <td className={styles.tempLabel}>CORE TEMP (°C)</td>
              <td className={styles.tempCell}>
                <input
                  type="text"
                  className={styles.tempInput}
                  value={form.coreTemp}
                  onChange={e => handleInputChange("coreTemp", e.target.value)}
                />
              </td>
            </tr>
            <tr>
              <td className={styles.tempLabel}>TEMPERTUER(°C)</td>
              <td className={styles.tempCell}>
                <input
                  type="text"
                  className={styles.tempInput}
                  value={form.temperature}
                  onChange={e => handleInputChange("temperature", e.target.value)}
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
