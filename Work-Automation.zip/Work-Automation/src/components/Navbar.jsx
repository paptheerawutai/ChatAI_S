import React from "react";
import { NavLink } from "react-router-dom";
import styles from "./css/Condition.module.css";

export default function Navbar() {
  return (
    <nav className={styles.navbar}>
      <ul className={styles.navList}>
        {/* <li>
          <NavLink to="/dd" className={({ isActive }) => isActive ? styles.active : styles.link}>
            All
          </NavLink>
        </li> */}
        <li>
          <NavLink to="/LLM" className={({ isActive }) => isActive ? styles.active : styles.link}>
            LLM
          </NavLink>
        </li>
{/*         
        <li>
          <NavLink to="/injection-actual" className={({ isActive }) => isActive ? styles.active : styles.link}>
            INJECTION Actual
          </NavLink>
        </li> */}
        
{/*         
        <li>
          <NavLink to="/screw-rotate" className={({ isActive }) => isActive ? styles.active : styles.link}>
            SCREW ROTATE
          </NavLink>
        </li>
        <li>
          <NavLink to="/ejector" className={({ isActive }) => isActive ? styles.active : styles.link}>
            EJECTOR
          </NavLink>
        </li>
        <li>
          <NavLink to="/mold-close" className={({ isActive }) => isActive ? styles.active : styles.link}>
            MOLDCLOSE
          </NavLink>
        </li>
        <li>
          <NavLink to="/mold-open" className={({ isActive }) => isActive ? styles.active : styles.link}>
            MOLDOPEN
          </NavLink>
        </li>
        <li>
          <NavLink to="/temperature" className={({ isActive }) => isActive ? styles.active : styles.link}>
            TEMPERATURE
          </NavLink>
        </li>
        <li>  
          <NavLink to="/hotrunner" className={({ isActive }) => isActive ? styles.active : styles.link}>
            HOTRUNNER
          </NavLink>
        </li>
        <li>
          <NavLink to="/valve-gate" className={({ isActive }) => isActive ? styles.active : styles.link}>
            VALVE GATE
          </NavLink>
        </li>
        <li>
          <NavLink to="/core-setting" className={({ isActive }) => isActive ? styles.active : styles.link}>
            CORE SETTING
          </NavLink>

        </li> */}
        {/* <li>
          <NavLink to="/lab" className={({ isActive }) => isActive ? styles.active : styles.link}>
            LAB
          </NavLink>
        </li> */}
        {/* <li>
          <NavLink to="/chat-llm" className={({ isActive }) => isActive ? styles.active : styles.link}>
            LLM_chat
          </NavLink>
        </li> */}
        


        
      </ul>
    </nav>
  );
}
