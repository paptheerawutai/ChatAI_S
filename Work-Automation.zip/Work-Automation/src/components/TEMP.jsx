
import React, { useState, useEffect } from "react";
import styles from "./css/TEMP.module.css";

const header = ["NH", "H1", "H2", "H3", "H4", "H5", "H6"];

export default function TEMP({ onDataChange, initialData }) {
  // สร้าง state สำหรับเก็บค่าจาก input (object per header)
  const [form, setForm] = useState(header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}));
  // state สำหรับเก็บ field ที่ต้องแสดงสีฟ้า (local highlight)
  const [localFlash, setLocalFlash] = useState([]);
  // state สำหรับเก็บค่าล่าสุดเพื่อเปรียบเทียบ
  const [lastData, setLastData] = useState({});

  // รับข้อมูลจาก initialData และตรวจสอบการเปลี่ยนแปลงแต่ละช่อง
  useEffect(() => {
    if (initialData) {
      // ตรวจสอบการเปลี่ยนแปลงก่อนอัปเดต form
      if (Object.keys(lastData).length > 0) {
        const changedCells = [];
        
        Object.keys(initialData).forEach(key => {
          const newValue = initialData[key];
          const oldValue = lastData[key];
          
          // เปรียบเทียบค่าแต่ละช่อง ถ้าต่างกันให้เพิ่มเข้า changedCells
          if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
            changedCells.push(key);
          }
        });

        if (changedCells.length > 0) {
          console.log('TEMP changed cells:', changedCells);
          setLocalFlash(changedCells);
          
          // ลบสีหลังจาก 5 วินาที
          setTimeout(() => {
            setLocalFlash([]);
          }, 30000);
        }
      }
      
      // อัปเดต form และ lastData
      setForm(header.reduce((acc, h) => ({ ...acc, [h]: initialData[h] || "" }), {}));
      setLastData(JSON.parse(JSON.stringify(initialData)));
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (idx, value) => {
    const key = header[idx];
    const newForm = { ...form, [key]: value };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.sectionTitle} style={{ textAlign: 'center' }}>TEMPERATURE SETTING</div>
      <table className={styles.table}>
        <colgroup>
          {header.map((_, i) => <col key={i} />)}
        </colgroup>
        <thead>
          <tr>
            {header.map(h => (
              <th key={h} className={styles.head}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          <tr>
            {header.map((h, idx) => {
              // ตรวจสอบว่าช่องนี้ควรเปลี่ยนสีหรือไม่
              const shouldHighlight = localFlash.includes(h);
              
              return (
                <td key={h} className={styles.yellow} style={{ 
                  width: '60px',
                  backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                  border: shouldHighlight ? '2px solid #0066cc' : '',
                  transition: 'all 0.3s ease'
                }}>
                  <input
                    type="text"
                    // style={{ 
                    //   width: '100%',
                    //   background: shouldHighlight ? '#cce6ff' : 'transparent',
                    //   outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                    //   color: shouldHighlight ? '#003366' : 'inherit',
                    //   transition: 'all 0.3s ease'
                    // }}
                    value={form[h]}
                    onChange={e => handleInputChange(idx, e.target.value)}
                  />
                </td>
              );
            })}
            <td className={styles.tolerance} rowSpan={2} style={{ borderRight: 'none', borderLeft: 'none', borderTop: 'none', borderBottom: 'none' }}>±10 ℃</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
