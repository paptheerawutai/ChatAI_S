import React, { useState, useEffect, useRef } from 'react';
import tableStyles from './css/TableCard.module.css';
import iPadStyles from './css/iPadOptimized.module.css';

import EJECTOR from './EJECTOR';
import MOLDCLOSE from './MOLDCLOSE';
import MOLDOPEN from './MOLDOPEN';
import TEMP from './TEMP';
import Hotrunner from './Hotrunner';
import ValveGate from './ValveGate';
import CORESETTING from './CORESETTING';
import LAB from './LAB';
import INJECTIONActual from './INJECTIONActual';
import SCREW_ROTATE from './SCREW_ROTATE';
import HOLDING_INJECTION from './HOLDING_INJECTION';
import axios from 'axios';
import ChatLLM from './ChatLLM';
import { ApiProvider } from '../contexts/ApiContext';
import App_main from '../main/main';

// ตั้งค่า API Configuration จาก Environment Variables
const API_BASE_URL = 'http://172.20.10.3:5005';
const API_KEY =  'mai4m-development-key';

// สร้าง axios instance พร้อม API Key
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'X-API-Key': API_KEY,
    'Content-Type': 'application/json'
  }
});

// แสดง config ใน console เพื่อ debug
console.log('🔧 API Configuration:', {
  baseURL: API_BASE_URL,
  apiKey: API_KEY ? `${API_KEY.substring(0, 10)}...` : 'Not set'
});

import Datacondition_part from './Datacondition_part';

function Page_all1() {
  // State สำหรับเก็บข้อมูลจากทุก component (รวม datacondition_part)
  const [allData, setAllData] = useState({
    injection: {},
    temperature_setting: {},
    hotrunner: {},
    holding_injection: {},
    screw_rotate: {},
    mold_close: {},
    mold_open: {},
    ejector: {},
    core_setting: {},
    valve_gate_sec: {},
    lubrication: {},
    datacondition_part: {},
    problem_name: ""
  });

  // State สำหรับเก็บข้อมูลล่าสุดที่อ่านมา
  const [lastAIData, setLastAIData] = useState(null);
  const [changedFields, setChangedFields] = useState([]);
  // State สำหรับเก็บ field ที่เปลี่ยนแปลงและต้องแสดงสีแดงชั่วคราว
  const [flashFields, setFlashFields] = useState([]);
  
  // State สำหรับจัดการเอฟเฟกต์การกดปุ่ม
  const [clickedButton, setClickedButton] = useState(null);

  // WebSocket states
  const [wsConnected, setWsConnected] = useState(false);
  const wsRef = useRef(null);
  const reconnectTimerRef = useRef(null);

  // โหลดข้อมูลจาก API - รองรับ partial update
  const handleRead = async () => {
    try {
      const res = await apiClient.get('/4M/condition_standard');
      
      if (res.data && res.data.condition_standard) {
        const newData = res.data.condition_standard;
        console.log('Standard data received:', newData);
        console.log('Available keys in received data:', Object.keys(newData));
        
        // ใช้ partial update แทน full replacement
        setAllData(prevData => {
          const updatedData = { ...prevData };
          
          Object.keys(newData).forEach(key => {
            const newVal = newData[key];
            const currentVal = prevData[key];
            
            if (typeof newVal === 'object' && newVal !== null) {
              // ถ้าเป็น object ให้ merge แทนการเขียนทับทั้งหมด
              const merged = {
                ...(currentVal && typeof currentVal === 'object' ? currentVal : {}),
                ...newVal
              };
              updatedData[key] = merged;
              console.log(`Merged ${key}:`, merged);
            } else {
              // ถ้าเป็น primitive value
              updatedData[key] = newVal;
              console.log(`Updated ${key}:`, newVal);
            }
          });
          
          return updatedData;
        });
        
        alert('✅ อ่านข้อมูล Standard สำเร็จ');
      } else {
        alert('⚠ ไม่พบข้อมูลใน API');
      }
    } catch (err) {
      console.error('API Error:', err);
      if (err.response?.status === 401) {
        alert('🔑 ต้องการ API Key สำหรับการเข้าถึง');
      } else if (err.response?.status === 403) {
        alert('🚫 API Key ไม่ถูกต้อง');
      } else if (err.response?.status === 404) {
        alert('🔍 ไม่พบ endpoint /4M/condition_standard');
      } else {
        alert('⚠ เกิดข้อผิดพลาด: ' + err.message);
      }
    }
  };

  // ฟังก์ชันแสดงข้อมูลแบบละเอียด (เทียบเท่า PowerShell JSON)
  const handleReadDetailed = async () => {
    try {
      const res = await apiClient.get('/4M/condition_standard');
      
      if (res.data) {
        // แสดงข้อมูลแบบละเอียดใน console
        console.log('=== DETAILED API RESPONSE ===');
        console.log(JSON.stringify(res.data, null, 2));
        console.log('=============================');
        
        // แสดงใน popup สำหรับดู
        const jsonString = JSON.stringify(res.data, null, 2);
        
        // สร้าง modal หรือใช้ confirm dialog
        const showDetails = window.confirm(
          `📋 ข้อมูล API ทั้งหมด:\n\n${jsonString.substring(0, 500)}...\n\n✅ กด OK เพื่อดูใน Console\n❌ กด Cancel เพื่อปิด`
        );
        
        if (showDetails) {
          console.log('Full JSON Data:', res.data);
          
          // อัปเดตข้อมูลด้วย
          if (res.data.condition_standard) {
            setAllData(prevData => ({ ...prevData, ...res.data.condition_standard }));
          }
        }
        
      } else {
        alert('⚠ ไม่มีข้อมูลใน response');
      }
    } catch (err) {
      console.error('API Error:', err);
      alert('⚠ เกิดข้อผิดพลาด: ' + err.message);
    }
  };

  const handleRead_ai = async () => {
    try {
      const res = await apiClient.get('/4M/condition_transient');
      console.log('Full response:', res.data);
      
      // ลองหลายโครงสร้าง API ที่เป็นไปได้
      let newData = null;
      if (res.data && res.data.condition && res.data.condition.condition_standard) {
        newData = res.data.condition.condition_standard;
      } else if (res.data && res.data.condition_standard) {
        newData = res.data.condition_standard;
      } else if (res.data && res.data.condition) {
        newData = res.data.condition;
      } else if (res.data) {
        newData = res.data;
      }
      
      console.log('AI data:', newData);
      console.log('Available keys in AI data:', newData ? Object.keys(newData) : 'No data');
      
      if (newData && typeof newData === 'object') {
        // เช็ค field ที่เปลี่ยนแปลงแบบละเอียด (field-level)
        const changed = [];
        
        // ใช้ partial update แทน full replacement
        setAllData(prevData => {
          const updatedData = { ...prevData }; // เก็บข้อมูลเดิมไว้ก่อน
          
          // อัพเดทเฉพาะข้อมูลที่ส่งมา
          Object.keys(newData).forEach(key => {
            const newVal = newData[key];
            const currentVal = prevData[key];
            
            if (typeof newVal === 'object' && newVal !== null) {
              // ถ้าเป็น object ให้ merge แทนการเขียนทับทั้งหมด
              const merged = {
                ...(currentVal && typeof currentVal === 'object' ? currentVal : {}),
                ...newVal
              };
              updatedData[key] = merged;
              console.log(`AI - Merged ${key}:`, merged);
              
              // เช็คการเปลี่ยนแปลง subfield
              Object.keys(newVal).forEach(subKey => {
                const oldSubVal = (currentVal && typeof currentVal === 'object') ? currentVal[subKey] : undefined;
                if (JSON.stringify(newVal[subKey]) !== JSON.stringify(oldSubVal)) {
                  changed.push(`${key}.${subKey}`);
                }
              });
            } else {
              // ถ้าเป็น primitive value
              updatedData[key] = newVal;
              console.log(`AI - Updated ${key}:`, newVal);
              
              if (JSON.stringify(newVal) !== JSON.stringify(currentVal)) {
                changed.push(key);
              }
            }
          });
          
          return updatedData;
        });
        
        setLastAIData(prev => ({
          ...(prev || {}),
          ...newData
        }));
        setFlashFields(changed);
        
        // สีแดงจางหายไปหลัง 15 วินาที
        if (changed.length > 0) {
          setTimeout(() => setFlashFields([]), 30000);
        }
        
        alert('✅ อ่านข้อมูลจาก AI สำเร็จ');
      } else {
        console.error('Invalid data structure:', res.data);
        alert('⚠ ไม่พบข้อมูลใน API หรือโครงสร้างข้อมูลไม่ถูกต้อง');
      }
    } catch (err) {
      console.error('API Error:', err);
      if (err.response?.status === 401) {
        alert('🔑 ต้องการ API Key สำหรับการเข้าถึง');
      } else if (err.response?.status === 403) {
        alert('🚫 API Key ไม่ถูกต้อง');
      } else if (err.response?.status === 404) {
        alert('🔍 ไม่พบ endpoint /4M/condition_transient');
      } else {
        alert('⚠ เกิดข้อผิดพลาด: ' + err.message);
      }
    }
  };
  
  const handleDataChange = (key, value) => {
    setAllData(prev => ({ ...prev, [key]: value }));
  };

  // Function สำหรับจัดการเอฟเฟกต์การกดปุ่ม
  const handleButtonClick = (buttonId, callback) => {
    setClickedButton(buttonId);
    
    // Execute the callback function
    callback();
    
    // Remove the clicked class after 3 seconds
    setTimeout(() => {
      setClickedButton(null);
    }, 3000);
  };

  // ===== WebSocket Functions =====
  const connectWebSocket = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      return; // Already connected
    }

    try {
      // เชื่อมต่อ WebSocket (ใช้ค่าจาก Environment Variable)
      const WS_URL = 'ws://localhost:1880/ws/condition_trigger';
      wsRef.current = new WebSocket(WS_URL);
      console.log('🔌 Connecting to WebSocket:', WS_URL);
      
      wsRef.current.onopen = () => {
        console.log('🔌 WebSocket connected for condition trigger');
        setWsConnected(true);
      };

      wsRef.current.onclose = () => {
        console.log('❌ WebSocket disconnected');
        setWsConnected(false);
        
        // Auto-reconnect after 3 seconds
        reconnectTimerRef.current = setTimeout(() => {
          console.log('🔄 Attempting to reconnect...');
          connectWebSocket();
        }, 3000);
      };

      wsRef.current.onerror = (error) => {
        console.error('🚨 WebSocket error:', error);
        setWsConnected(false);
      };

      wsRef.current.onmessage = (event) => {
        console.log('📨 WebSocket message received:', event.data);
        
        try {
          const data = JSON.parse(event.data);
          console.log('� Parsed JSON data:', data);
          
          // ตรวจสอบว่าเป็นข้อมูลที่ต้องการให้เรียก handleRead_ai
          if (data.event === 'trigger_condition_read' || data.action === 'read_ai_data' || data.event === 'condition_update') {
            console.log('🎯 Triggering handleRead_ai from WebSocket...');
            
            // รอ 1.5 วินาที ตามที่ user ต้องการ แล้วจึงเรียก handleRead_ai
            setTimeout(() => {
              handleButtonClick('ai', handleRead_ai);
            }, 1500);
          } else {
            // สำหรับข้อความ JSON อื่นๆ ก็เรียก handleRead_ai เช่นกัน
            console.log('🔄 Any JSON message received, triggering API read...');
            setTimeout(() => {
              handleButtonClick('ai', handleRead_ai);
            }, 1500);
          }
          
        } catch (error) {
          console.log('📡 Non-JSON message received, triggering handleRead_ai...');
          console.log('📝 Raw message:', event.data);
          
          // หากไม่ได้เป็น JSON ให้ถือว่าเป็น trigger ทุกครั้ง
          setTimeout(() => {
            handleButtonClick('ai', handleRead_ai);
          }, 1500);
        }
      };

    } catch (error) {
      console.error('❌ WebSocket connection error:', error);
      setWsConnected(false);
    }
  };

  // ===== WebSocket Effect =====
  useEffect(() => {
    connectWebSocket();
    
    return () => {
      if (reconnectTimerRef.current) {
        clearTimeout(reconnectTimerRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  // ===== API Test Function =====
  const testAPIConnection = async () => {
    try {
      console.log('🔌 Testing API connection...');
      
      // 1. ทดสอบ Health Check
      const healthRes = await apiClient.get('/health');
      console.log('✅ Health check:', healthRes.data);
      
      // 2. ทดสอบ Auth Info
      const authRes = await apiClient.get('/auth/info');
      console.log('🔑 Auth info:', authRes.data);
      
      alert(`✅ API เชื่อมต่อสำเร็จ!\n\nServer Status: ${healthRes.data.status}\nAuth Mode: ${authRes.data.authMode}\nDatabase: ${healthRes.data.database || 'N/A'}`);
      
    } catch (err) {
      console.error('❌ API Connection failed:', err);
      
      if (err.response?.status === 401) {
        alert('🔑 API Key ไม่ถูกต้อง หรือหายไป\n\nกรุณาตรวจสอบ API_KEY ในโค้ด');
      } else if (err.response?.status === 403) {
        alert('🚫 API Key ถูกปฏิเสธ\n\nอาจจะ rate limit หรือ key หมดอายุ');
      } else if (err.code === 'ECONNREFUSED') {
        alert('🔌 ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้\n\nตรวจสอบ:\n- เซิร์ฟเวอร์ API เปิดหรือไม่\n- URL: ' + API_BASE_URL);
      } else {
        alert('⚠️ เกิดข้อผิดพลาด: ' + (err.message || 'ไม่ทราบสาเหตุ'));
      }
    }
  };

  // ===== WebSocket Test Function =====
  const sendWebSocketTrigger = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      const message = {
        event: 'trigger_condition_read',
        timestamp: new Date().toISOString(),
        source: 'manual_trigger'
      };
      wsRef.current.send(JSON.stringify(message));
      console.log('📤 Sent WebSocket trigger:', message);
    } else {
      console.warn('⚠️ WebSocket not connected');
      alert('WebSocket ไม่ได้เชื่อมต่อ');
    }
  };

  // Debug: แสดงค่า allData.holding_injection
  console.log('Page_all1 allData.holding_injection:', allData.holding_injection);

  // Callback สำหรับ input ปัญหา (dropdown + custom)
  const [customProblem, setCustomProblem] = useState("");
  const handleProblemNameChange = (e) => {
    const value = e.target.value;
    if (value === "อื่นๆ") {
      setAllData(prev => ({ ...prev, problem_name: customProblem }));
    } else {
      setAllData(prev => ({ ...prev, problem_name: value }));
      setCustomProblem("");
    }
  };
  const handleCustomProblemChange = (e) => {
    setCustomProblem(e.target.value);
    setAllData(prev => ({ ...prev, problem_name: e.target.value }));
  };

  // Callback สำหรับรับข้อมูลจาก Datacondition_part
  const handleDataConditionPartChange = (data) => {
    console.log('Datacondition_part:', data);
    setAllData(prev => ({ ...prev, datacondition_part: data }));
  };
  

  // ส่งข้อมูลทั้งหมดออก (allData รวม datacondition_part แล้ว)
  const handleSend = async () => {
    try {
      const res = await apiClient.post('/4M/condition_standard', allData);
      console.log('Response:', res.data);
      alert('✅ ส่งข้อมูลสำเร็จ: ' + (res.data.message || 'บันทึกข้อมูลแล้ว'));
    } catch (err) {
      console.error('API Error:', err);
      if (err.response?.status === 401) {
        alert('🔑 ต้องการ API Key สำหรับการเข้าถึง');
      } else if (err.response?.status === 403) {
        alert('🚫 API Key ไม่ถูกต้อง');
      } else if (err.response?.status === 404) {
        alert('🔍 ไม่พบ endpoint /4M/condition_standard');
      } else if (err.response?.status === 413) {
        alert('📦 ข้อมูลมีขนาดใหญ่เกินไป');
      } else {
        alert('⚠ เกิดข้อผิดพลาด: ' + err.message);
      }
    }
  };

   

  return (
    <ApiProvider handleRead_ai={handleRead_ai} handleButtonClick={handleButtonClick}>
      <div>
        <div className='CONDITION STANDARD-data'>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
            <h2 className={iPadStyles.pageTitle}>CONDITION STANDARD</h2>
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '8px',
              padding: '6px 12px',
              borderRadius: '20px',
              background: wsConnected ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)',
              border: `1px solid ${wsConnected ? '#22c55e' : '#ef4444'}`,
              fontSize: '12px',
              fontWeight: '600'
            }}>
              <span style={{ 
                width: '8px', 
                height: '8px', 
                borderRadius: '50%', 
                background: wsConnected ? '#22c55e' : '#ef4444'
              }}></span>
              WebSocket {wsConnected ? 'Connected' : 'Disconnected'}
            </div>
          </div>
        
          {/* เพิ่มฟอร์ม Datacondition_part ด้านบน */}
          <div className={iPadStyles.dataconditionWrapper}>
            <Datacondition_part onDataChange={handleDataConditionPartChange} initialData={allData.datacondition_part} />
          </div>


        <div className={`${tableStyles.gridContainer} ${iPadStyles.gridContainerWrapper}`}>

          <div className={tableStyles.card1}>
            <INJECTIONActual onDataChange={data => handleDataChange('injection', data)} initialData={allData.injection} />
            {/* LAB ไม่ต้อง initialData เพราะไม่มีข้อมูลใน API ตัวอย่าง */}

            



          </div>
          <div className={tableStyles.card2}>
            <div className={tableStyles.rf1}>
              <HOLDING_INJECTION onDataChange={data => handleDataChange('holding_injection', data)} initialData={allData.holding_injection} />
            </div>
            <div className={tableStyles.rfi}>
              <SCREW_ROTATE onDataChange={data => handleDataChange('screw_rotate', data)} initialData={allData.screw_rotate} />
            </div>
          </div>

          {/* Card3: Temperature & Controls */}
          <div className={`${tableStyles.card3} ${iPadStyles.additionalCard}`}>
            <div className={iPadStyles.cardGrid}>
              <div className={iPadStyles.cardColumn}>
                <EJECTOR onDataChange={data => handleDataChange('ejector', data)} initialData={allData.ejector} />
                <MOLDCLOSE onDataChange={data => handleDataChange('mold_close', data)} initialData={allData.mold_close} />
                <MOLDOPEN onDataChange={data => handleDataChange('mold_open', data)} initialData={allData.mold_open} />
                <LAB onDataChange={data => handleDataChange('lubrication', data)} initialData={allData.lubrication} />
              </div>
              <div className={iPadStyles.cardColumn}>
                <TEMP onDataChange={data => handleDataChange('temperature_setting', data)} initialData={allData.temperature_setting} />
                <Hotrunner onDataChange={data => handleDataChange('hotrunner', data)} initialData={allData.hotrunner} />
                <ValveGate onDataChange={data => handleDataChange('valve_gate_sec', data)} initialData={allData.valve_gate_sec} />
                <CORESETTING onDataChange={data => handleDataChange('core_setting', data)} initialData={allData.core_setting} />
              </div>
              
            </div>
          </div>
        </div>
      
        </div>

        {/* Content Spacer */}
        <div className={iPadStyles.contentSpacer}></div>

        {/* Bottom Navigation Bar */}
        <div className={iPadStyles.bottomNavbar}>
          <div className={iPadStyles.navbarContent}>
            {/* Problem Selection Section */}
            <div className={iPadStyles.navbarProblemSection}>
              <label htmlFor="navbar_problem_name" className={iPadStyles.navbarProblemLabel}>
                ชื่อปัญหางาน:
              </label>
              <select
                id="navbar_problem_name"
                value={["แหว่ง", "ครีบ", "ปกติ","จุดดำ","impoveCT","Standard"].includes(allData.problem_name) ? allData.problem_name : (customProblem ? "อื่นๆ" : "")}
                onChange={handleProblemNameChange}
                className={iPadStyles.navbarProblemSelect}
              >
                <option value="">-- เลือกปัญหา --</option>
                <option value="แหว่ง">แหว่ง</option>
                <option value="ครีบ">ครีบ</option>
                <option value="จุดดำ">จุดดำ</option>
                <option value="impoveCT">impoveCT</option>
                <option value="Standard">Standard</option>
              </select>
              {((allData.problem_name === "อื่นๆ") || (customProblem && !["แหว่ง", "ครีบ"].includes(allData.problem_name))) && (
                <input
                  type="text"
                  value={customProblem}
                  onChange={handleCustomProblemChange}
                  className={iPadStyles.navbarProblemInput}
                  placeholder="ระบุปัญหาเอง"
                />
              )}
            </div>

            {/* Action Buttons */}
            <div className={iPadStyles.navbarButtonGroup}>
              <button
                className={`${iPadStyles.navbarActionButton} ${clickedButton === 'read' ? 'clicked' : ''}`}
                onClick={() => handleButtonClick('read', handleRead)}
              >
                 Standard Now
              </button>

              {/* <button
                className={`${iPadStyles.navbarActionButton} ${clickedButton === 'detailed' ? 'clicked' : ''}`}
                onClick={() => handleButtonClick('detailed', handleReadDetailed)}
                title="แสดงข้อมูล JSON แบบละเอียด"
              >
                📋 Detailed JSON
              </button> */}

              <button
                className={`${iPadStyles.navbarActionButton} ${clickedButton === 'ai' ? 'clicked' : ''}`}
                onClick={() => handleButtonClick('ai', handleRead_ai)}
              >
                Data from AI
              </button>


              <button
                className={`${iPadStyles.navbarActionButtonGreen} ${clickedButton === 'send' ? 'clicked' : ''}`}
                onClick={() => handleButtonClick('send', handleSend)}
              >
                 SaveCondition
              </button>

              {/* <button
                className={`${iPadStyles.navbarActionButton} ${clickedButton === 'wstest' ? 'clicked' : ''}`}
                onClick={() => handleButtonClick('wstest', sendWebSocketTrigger)}
                title="ทดสอบส่ง WebSocket trigger"
              >
                🔗 WS Test
              </button> */}

              {/* <button
                className={`${iPadStyles.navbarActionButton} ${clickedButton === 'apitest' ? 'clicked' : ''}`}
                onClick={() => handleButtonClick('apitest', testAPIConnection)}
                title="ทดสอบการเชื่อมต่อ API"
              >
                🔌 API Test
              </button> */}


              {/* <button
                className={`${iPadStyles.navbarActionButton} ${clickedButton === 'test' ? 'clicked' : ''}`}
                onClick={() => handleButtonClick('test', () => {
                  // ข้อมูลทดสอบสำหรับ HOLDING_INJECTION
                  const testData = {
                    ...allData,
                    holding_injection: {
                      pressure: { HP4: "150", HP3: "140", HP2: "130", HP1: "120", "5TH": "110", "4TH": "100", "3RD": "90", "2ND": "80", "1ST": "70" },
                      speed: { HP4: "50", HP3: "45", HP2: "40", HP1: "35", "5TH": "30", "4TH": "25", "3RD": "20", "2ND": "15", "1ST": "10" },
                      time: { HP4: "5", HP3: "4", HP2: "3", HP1: "2", "5TH": "1.5", "4TH": "1.2", "3RD": "1.0", "2ND": "0.8", "1ST": "0.5" },
                      position: { HP4: "100", HP3: "90", HP2: "80", HP1: "70", "5TH": "60", "4TH": "50", "3RD": "40", "2ND": "30", "1ST": "20" }
                    }
                  };
                  setAllData(testData);
                })}
              >
                🧪 ข้อมูลทดสอบ
              </button> */}
            </div>
          </div>
        </div>
      </div>
      
      {/* App_main component สำหรับ Chat */}
      <App_main />
    </ApiProvider>

  );
}

export default Page_all1;