import React, { useState, useEffect } from "react";
import styles from "./css/MOLDCLOSE.module.css";

const header = ["LS2", "MS", "HS", "LS1"];
const rows = ["PRESSURE", "SPEED", "POSITION"];

export default function MOLDOPEN({ onDataChange, initialData }) {
  // สร้าง state สำหรับเก็บค่าจาก input (object per header)
  const [form, setForm] = useState(
    rows.reduce((acc, row) => ({
      ...acc,
      [row]: header.reduce((hAcc, h) => ({ ...hAcc, [h]: "" }), {})
    }), {})
  );
  // state สำหรับเก็บ field ที่ต้องแสดงสีฟ้า (local highlight)
  const [localFlash, setLocalFlash] = useState([]);
  // state สำหรับเก็บค่าล่าสุดเพื่อเปรียบเทียบ
  const [lastData, setLastData] = useState({});

  // รับข้อมูลจาก initialData และตรวจสอบการเปลี่ยนแปลงแต่ละช่อง
  useEffect(() => {
    if (initialData) {
      // ตรวจสอบการเปลี่ยนแปลงก่อนอัปเดต form
      if (Object.keys(lastData).length > 0) {
        const changedCells = [];
        
        rows.forEach(row => {
          if (initialData[row] && lastData[row]) {
            header.forEach(h => {
              const newValue = initialData[row][h];
              const oldValue = lastData[row][h];
              
              if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
                changedCells.push(`${row}.${h}`);
              }
            });
          }
        });

        if (changedCells.length > 0) {
          console.log('MOLDOPEN changed cells:', changedCells);
          setLocalFlash(changedCells);
          
          // ลบสีหลังจาก 5 วินาที
          setTimeout(() => {
            setLocalFlash([]);
          }, 30000);
        }
      }
      
      // อัปเดต form และ lastData
      setForm(
        rows.reduce((acc, row) => ({
          ...acc,
          [row]: header.reduce((hAcc, h) => ({ ...hAcc, [h]: initialData[row]?.[h] || "" }), {})
        }), {})
      );
      setLastData(JSON.parse(JSON.stringify(initialData)));
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (rowKey, idx, value) => {
    const key = header[idx];
    const newForm = {
      ...form,
      [rowKey]: {
        ...form[rowKey],
        [key]: value
      }
    };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div className={styles.wrap}>
      <div style={{ fontWeight: "bold", fontSize: "20px", marginBottom: "8px" }}>MOLD OPEN</div>
      <table className={styles.table}>
        <colgroup>
          {header.map((_, i) => <col key={i} />)}
          <col />
        </colgroup>
        <thead>
          <tr>
            {header.map(h => (
              <th key={h} className={styles.head}>{h}</th>
            ))}
            <th className={styles.tolerance}></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rIdx) => (
            <tr key={row}>
              {header.map((h, idx) => {
                const cellKey = `${row}.${h}`;
                const shouldHighlight = localFlash.includes(cellKey);
                
                return (
                  <td key={h} className={styles.yellow} style={{
                    backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                    border: shouldHighlight ? '2px solid #0066cc' : '',
                    transition: 'all 0.3s ease'
                  }}>
                    <input
                      type="text"
                      // style={{
                      //   background: shouldHighlight ? '#cce6ff' : 'transparent',
                      //   outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                      //   color: shouldHighlight ? '#003366' : 'inherit',
                      //   transition: 'all 0.3s ease'
                      // }}
                      value={form[row][h]}
                      onChange={e => handleInputChange(row, idx, e.target.value)}
                    />
                  </td>
                );
              })}
              <td className={styles.tolerance}>
                {row === "PRESSURE" && <>±10 kg/cm<sup>2</sup></>}
                {row === "SPEED" && <>±10 mm/s</>}
                {row === "POSITION" && <>±10 mm</>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
