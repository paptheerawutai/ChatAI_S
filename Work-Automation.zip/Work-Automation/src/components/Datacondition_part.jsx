
import React, { useState, useEffect } from "react";
import styles from "./css/DataconditionPart.module.css";

export default function Datacondition_part({ onDataChange, initialData }) {
  const [form, setForm] = useState({
    machine_no: "",
    date: "",
    memory_no: "",
    customer: "",
    part_name: "",
    part_code: "",
    machine_size: "",
    hopper_dryer: "",
    hopper_dryer_time: "",
    mat_name: "",
    pcs_weight_std: "",
    pcs_weight_actual: "",
    runner_weight_std: "",
    runner_weight_actual: "",
    cavity_set: "",
  });

  useEffect(() => {
    if (initialData) {
      setForm((prev) => ({ ...prev, ...initialData }));
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    const newForm = { ...form, [name]: value };
    setForm(newForm);
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div className={styles.card}>
      <table className={styles.table}>
        <tbody>
          <tr>
            <td className={styles.label}>MACHINE NO.:</td>
            <td className={styles.inputCell}>
              <input
                name="machine_no"
                value={form.machine_no}
                onChange={handleChange}
                className={styles.input}
              />
            </td>
            <td className={styles.label}>DATE</td>
            <td className={styles.inputCell}>
              <input
                name="date"
                value={form.date}
                onChange={handleChange}
                className={styles.input}
              />
            </td>
            <td className={styles.label}>MEMORY NO.</td>
            <td className={styles.inputCell}>
              <input
                name="memory_no"
                value={form.memory_no}
                onChange={handleChange}
                className={styles.input}
              />
            </td>
          </tr>
          <tr>
            <td className={styles.label}>CUSTOMER</td>
            <td className={styles.inputCell}>
              <input
                name="customer"
                value={form.customer}
                onChange={handleChange}
                className={styles.input}
              />
            </td>
            <td className={styles.label}>MACHINE SIZE :</td>
            <td className={styles.inputCell}>
              <div className={styles.inlineGroup}>
                <input
                  name="machine_size"
                  value={form.machine_size}
                  onChange={handleChange}
                  className={`${styles.input} ${styles.smallInput}`}
                />
                <span className={styles.suffix}>Ton</span>
              </div>
            </td>
            <td className={styles.label}>MAT&apos; NAME :</td>
            <td className={styles.inputCell}>
              <input
                name="mat_name"
                value={form.mat_name}
                onChange={handleChange}
                className={styles.input}
              />
            </td>
          </tr>
          <tr>
            <td className={styles.label}>PART NAME :</td>
            <td className={styles.inputCell}>
              <input
                name="part_name"
                value={form.part_name}
                onChange={handleChange}
                className={styles.input}
              />
            </td>
            <td className={styles.label}>HOPPER DRYER :</td>
            <td className={styles.inputCell}>
              <div className={styles.inlineGroup}>
                <input
                  name="hopper_dryer"
                  value={form.hopper_dryer}
                  onChange={handleChange}
                  className={`${styles.input} ${styles.smallInput}`}
                />
                <span className={styles.suffix}>±15°C</span>
              </div>
            </td>
            <td className={styles.label}>PCS / WEIGH :</td>
            <td className={styles.inputCell}>
              <div className={styles.inlineGroup}>
                <span className={styles.inlineLabel}>STD</span>
                <input
                  name="pcs_weight_std"
                  value={form.pcs_weight_std}
                  onChange={handleChange}
                  className={`${styles.input} ${styles.smallInput}`}
                />
                <span className={styles.suffix}>g.</span>
                <span className={`${styles.inlineLabel} ${styles.inlineSpacing}`}>Actual</span>
                <input
                  name="pcs_weight_actual"
                  value={form.pcs_weight_actual}
                  onChange={handleChange}
                  className={`${styles.input} ${styles.smallInput} ${styles.actualInput}`}
                />
                <span className={styles.suffix}>g.</span>
              </div>
            </td>
          </tr>
          <tr>
            <td className={styles.label}>PART CODE :</td>
            <td className={styles.inputCell}>
              <input
                name="part_code"
                value={form.part_code}
                onChange={handleChange}
                className={styles.input}
              />
            </td>
            <td className={styles.label}>HOPPER DRYER TIME :</td>
            <td className={styles.inputCell}>
              <div className={styles.inlineGroup}>
                <input
                  name="hopper_dryer_time"
                  value={form.hopper_dryer_time}
                  onChange={handleChange}
                  className={`${styles.input} ${styles.smallInput}`}
                />
                <span className={styles.suffix}>±1hr.</span>
              </div>
            </td>
            <td className={styles.label}>RUNNER / WEIGHT :</td>
            <td className={styles.inputCell}>
              <div className={styles.inlineGroup}>
                <span className={styles.inlineLabel}>STD</span>
                <input
                  name="runner_weight_std"
                  value={form.runner_weight_std}
                  onChange={handleChange}
                  className={`${styles.input} ${styles.smallInput}`}
                />
                <span className={styles.suffix}>g.</span>
                <span className={`${styles.inlineLabel} ${styles.inlineSpacing}`}>Actual</span>
                <input
                  name="runner_weight_actual"
                  value={form.runner_weight_actual}
                  onChange={handleChange}
                  className={`${styles.input} ${styles.smallInput} ${styles.actualInput}`}
                />
                <span className={styles.suffix}>g.</span>
              </div>
            </td>
          </tr>
          <tr>
            <td colSpan={5} className={styles.trailingLabel}>CAVITY/SET</td>
            <td className={styles.inputCell}>
              <input
                name="cavity_set"
                value={form.cavity_set}
                onChange={handleChange}
                className={`${styles.input} ${styles.smallInput}`}
              />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}