
import React, { useState, useEffect } from 'react';
import tableStyles from './css/TableCard.module.css';

const header = ['SCW1', 'SCW2', 'SCW3', 'POSI. BACK (A)', 'POSI. BACK (B)'];
const rows = [
  { key: "pressure", label: "PRESSURE", tol: "±10 kg/cm²", yellow: true },
  { key: "", label: "", tol: "", yellow: false },
  { key: "speed", label: "SPEED", tol: "±10 mm/s", yellow: true },
  { key: "", label: "", tol: "", yellow: false },
  { key: "position", label: "POSITION", tol: "±10 mm", yellow: true },
];

function SCREW_ROTATE({ onDataChange, initialData }) {
  // สร้าง state สำหรับเก็บค่าจาก input (object per key)
  const [form, setForm] = useState({
    pressure: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
    speed: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
    position: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {})
  });
  // state สำหรับเก็บ field ที่ต้องแสดงสีฟ้า (local highlight)
  const [localFlash, setLocalFlash] = useState([]);
  // state สำหรับเก็บค่าล่าสุดเพื่อเปรียบเทียบ
  const [lastData, setLastData] = useState({});

  // รับข้อมูลจาก initialData และตรวจสอบการเปลี่ยนแปลงแต่ละช่อง
  useEffect(() => {
    if (initialData) {
      // ตรวจสอบการเปลี่ยนแปลงก่อนอัปเดต form
      if (Object.keys(lastData).length > 0) {
        const changedCells = [];
        
        Object.keys(initialData).forEach(section => {
          if (initialData[section] && typeof initialData[section] === 'object') {
            Object.keys(initialData[section]).forEach(key => {
              const newValue = initialData[section][key];
              const oldValue = lastData[section]?.[key];
              
              // เปรียบเทียบค่าแต่ละช่อง ถ้าต่างกันให้เพิ่มเข้า changedCells
              if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
                changedCells.push(`${section}.${key}`);
              }
            });
          }
        });

        if (changedCells.length > 0) {
          console.log('SCREW_ROTATE changed cells:', changedCells);
          setLocalFlash(changedCells);
          
          // ลบสีหลังจาก 5 วินาที
          setTimeout(() => {
            setLocalFlash([]);
          }, 30000);
        }
      }
      
      // อัปเดต form และ lastData
      setForm(initialData);
      setLastData(JSON.parse(JSON.stringify(initialData)));
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const [activeInput, setActiveInput] = useState(null);
  const handleInputChange = (rowKey, colIdx, value) => {
    if (!rowKey) return;
    const colKey = header[colIdx];
    const newForm = {
      ...form,
      [rowKey]: {
        ...form[rowKey],
        [colKey]: value
      }
    };
    setForm(newForm);
    setActiveInput(`${rowKey}.${colKey}`);
    setTimeout(() => setActiveInput(null), 1500);
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div>
      <div className={tableStyles.sectionTitle}>SCREW ROTATE</div>
      <table className={tableStyles.card2Table}>
        <thead>
          <tr>
            <th></th>
            {header.map(h => (
              <th key={h}>{h}</th>
            ))}
            <th></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, idx) => (
            <tr key={idx}>
              <td style={{ fontWeight: r.yellow ? 'bold' : 'normal' }}>{r.label}</td>
              {header.map((h, i) => {
                // ตรวจสอบว่าช่องนี้ควรเปลี่ยนสีหรือไม่ (เฉพาะช่องที่มีค่าเปลี่ยน)
                const cellKey = `${r.key}.${h}`;
                const shouldHighlight = localFlash.includes(cellKey) || activeInput === cellKey;
                
                return r.yellow ? (
                  <td key={i} className={tableStyles.stdColBg} style={{
                    backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                    border: shouldHighlight ? '2px solid #0066cc' : '',
                    transition: 'all 0.3s ease'
                  }}>
                    <input
                      type="text"
                      // style={{ 
                      //   width: '90%', 
                      //   border: 'none', 
                      //   background: shouldHighlight ? '#cce6ff' : 'transparent', 
                      //   fontSize: '16px', 
                      //   padding: '2px 4px',
                      //   transition: 'all 0.3s ease',
                      //   outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                      //   color: shouldHighlight ? '#003366' : 'inherit'
                      // }}
                      value={form[r.key] ? form[r.key][h] : ""}
                      onChange={e => handleInputChange(r.key, i, e.target.value)}
                    />
                  </td>
                ) : (
                  <td key={i}></td>
                );
              })}
              <td>{r.tol}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default SCREW_ROTATE;