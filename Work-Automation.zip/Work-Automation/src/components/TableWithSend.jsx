// ใน component ที่มีตารางและปุ่ม
import React, { useState } from "react";

export default function TableWithSend() {
  const [tableData, setTableData] = useState([
    { col1: "", col2: "" },
    { col1: "", col2: "" },
    // ...เพิ่มแถวตามต้องการ
  ]);

  const handleInputChange = (rowIdx, colName, value) => {
    const newData = [...tableData];
    newData[rowIdx][colName] = value;
    setTableData(newData);
  };

  const handleSend = () => {
    console.log("ข้อมูลที่ส่งออก:", tableData);
    // สามารถแยกข้อมูลแต่ละช่องได้ เช่น
    tableData.forEach((row, idx) => {
      console.log(`แถวที่ ${idx + 1}:`, row);
    });
  };

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>คอลัมน์ 1</th>
            <th>คอลัมน์ 2</th>
          </tr>
        </thead>
        <tbody>
          {tableData.map((row, rowIdx) => (
            <tr key={rowIdx}>
              <td>
                <input
                  value={row.col1}
                  onChange={e => handleInputChange(rowIdx, "col1", e.target.value)}
                />
              </td>
              <td>
                <input
                  value={row.col2}
                  onChange={e => handleInputChange(rowIdx, "col2", e.target.value)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={handleSend}>ส่งข้อมูล</button>
    </div>
  );
}