import { useState, useEffect, useRef } from "react";

export default function LLM_AI() {
  const [question, setQuestion] = useState("");
  const [results, setResults] = useState(null);
  const [status, setStatus] = useState("🔌 Connecting...");
  const wsRef = useRef(null);

  useEffect(() => {
    const ws = new WebSocket("ws://localhost:8080");
    wsRef.current = ws;

    ws.onopen = () => setStatus("✅ Connected to server");
    ws.onmessage = (msg) => {
      const data = JSON.parse(msg.data);
      if (data.type === "results") {
        setResults(data.data);
        setStatus("✅ Results received");
      } else if (data.type === "error") {
        setResults([{ title: "Error", text: data.message }]);
        setStatus("❌ Error from server");
      }
    };
    ws.onclose = () => setStatus("❌ Disconnected from server");

    return () => ws.close();
  }, []);

  const sendQuestion = () => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(question);
      setStatus("⏳ Waiting for results...");
      setResults(null);
    }
  };

  return (
    <div style={{ fontFamily: "Arial", padding: "20px" }}>
      <h2>🤖 AI Vector Search</h2>
      <p>{status}</p>

      <div style={{ marginBottom: "10px" }}>
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="พิมพ์คำถาม..."
          style={{
            padding: "8px",
            width: "70%",
            marginRight: "10px",
            border: "1px solid #ccc",
            borderRadius: "6px"
          }}
        />
        <button
          onClick={sendQuestion}
          style={{
            padding: "8px 16px",
            border: "none",
            borderRadius: "6px",
            background: "#4CAF50",
            color: "white",
            cursor: "pointer"
          }}
        >
          ส่ง
        </button>
      </div>

      <div
        style={{
          padding: "10px",
          border: "1px solid #eee",
          borderRadius: "6px",
          background: "#f9f9f9"
        }}
      >
        {results ? (
          <pre>{JSON.stringify(results, null, 2)}</pre>
        ) : (
          <p>❔ ยังไม่มีผลลัพธ์</p>
        )}
      </div>
    </div>
  );
}
