import React, { useState, useEffect, useRef } from "react";
import "./css/ChatLLM.css";

export default function ChatLLM() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { sender: "bot", text: "สวัสดีครับ 👋 ส่งข้อความหรือรูปมาได้เลย" },
  ]);
  const [input, setInput] = useState("");
  const [image, setImage] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [loading, setLoading] = useState(false);

  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading, isOpen]);

  const OPENROUTER_API_KEY =
    "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";

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      setPreviewUrl(URL.createObjectURL(file));
    }
  };

  const removeImage = () => {
    setImage(null);
    setPreviewUrl(null);
  };

  const isLikelyJSON = (txt) => {
    if (!txt) return false;
    const t = txt.trim();
    return (t.startsWith("{") && t.endsWith("}")) || (t.startsWith("[") && t.endsWith("]"));
  };

  const handleSend = async () => {
    if (input.trim() === "" && !image) return;

    const newMessages = [
      ...messages,
      {
        sender: "user",
        text: input || (image ? "[ส่งรูป]" : ""),
        image: previewUrl || null,
      },
    ];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      let imageBase64 = null;
      if (image) {
        const reader = new FileReader();
        imageBase64 = await new Promise((resolve) => {
          reader.onloadend = () => resolve(reader.result.split(",")[1]);
          reader.readAsDataURL(image);
        });
      }

      const payload = {
        model: "openai/gpt-4o-mini",
        messages: [
          {
            role: "system",
            content:
              "คุณคือตัวช่วยอัจฉริยะที่ต้องตอบเป็นภาษาไทยเสมอ ไม่ว่าจะได้รับคำถามหรือรูปใด ๆ ก็ตาม",
          },
          {
            role: "user",
            content: [
              { type: "text", text: input || "วิเคราะห์รูปนี้ให้หน่อย" },
              ...(imageBase64
                ? [
                    {
                      type: "image_url",
                      image_url: { url: `data:image/jpeg;base64,${imageBase64}` },
                    },
                  ]
                : []),
            ],
          },
        ],
      };

      const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${OPENROUTER_API_KEY}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      const reply = data?.choices?.[0]?.message?.content || "⚠️ ไม่มีคำตอบ";

      setMessages([...newMessages, { sender: "bot", text: reply }]);
    } catch (err) {
      console.error(err);
      setMessages([
        ...newMessages,
        { sender: "bot", text: "❌ เกิดข้อผิดพลาดในการเรียก API" },
      ]);
    } finally {
      setImage(null);
      setPreviewUrl(null);
      setLoading(false);
    }
  };

  return (
    <div className="chat-container">
      {!isOpen && (
        <button className="chat-button" onClick={() => setIsOpen(true)}>
          💬 Chat
        </button>
      )}

      {isOpen && (
        <>
          <div className="chat-window">
            <div className="chat-header">
              <span>Smart Chat</span>
              <button className="close-btn" onClick={() => setIsOpen(false)}>
                ✖
              </button>
            </div>

            <div
              className="chat-body"
              onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                e.currentTarget.style.setProperty("--mouse-x", `${x}px`);
                e.currentTarget.style.setProperty("--mouse-y", `${y}px`);
              }}
            >
              {messages.map((msg, idx) => (
                <div key={idx} className={`chat-message ${msg.sender}`}>
                  {msg.image && (
                    <img src={msg.image} alt="preview" className="chat-image" />
                  )}

                  {/* ✅ คอนเทนเนอร์เลื่อนภายในข้อความยาว */}
                  <div className="chat-content">
                    {isLikelyJSON(msg.text) ? (
                      <pre className="chat-json">{msg.text}</pre>
                    ) : (
                      <span>{msg.text}</span>
                    )}
                  </div>
                </div>
              ))}

              {loading && (
                <div className="chat-message bot">
                  <div className="chat-content">⏳ กำลังประมวลผล...</div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="chat-footer">
              <label htmlFor="file-upload" className="upload-btn">+</label>
              <input
                id="file-upload"
                type="file"
                accept="image/*"
                style={{ display: "none" }}
                onChange={handleImageChange}
              />

              <input
                type="text"
                placeholder="พิมพ์ข้อความ..."
                className="chat-input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
              />

              <button className="send-btn" onClick={handleSend}>➤</button>
            </div>
          </div>

          {previewUrl && (
            <div className="chat-preview">
              <img src={previewUrl} alt="preview" />
              <button className="remove-img" onClick={removeImage}>✖</button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
