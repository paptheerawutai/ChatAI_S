// MOLDCLOSE.jsx — Injection panel styled like the Excel sheet screenshot
// import styles from "./css/Condition.module.css";
import styles from "../components/css/INJECTIONActual.module.css";
import tableStyles from './css/TableCard.module.css';

import React, { useState, useEffect } from "react";

export default function INJECTIONActual({ onDataChange, initialData }) {
  const rows = [
    { key: "inj_time", label: "INJ.TIME:",       tol: "±3",  unit: "Sec" },
    { key: "cooling_time", label: "COOLING TIME :",  tol: "±5",  unit: "Sec" },
    { key: "cycle_time", label: "CYCLE TIME :",    tol: "±5",  unit: "Sec" },
    { key: "cushion", label: "CUSHION :",       tol: "±5",  unit: "mm." },
    { key: "scw_monitor", label: "SCW. MONITOR :",  tol: "±10", unit: "Sec" },
    { key: "bp_pressure", label: "B.P. Pressure",   tol: "±1",  unit: (<><span>kg/s</span><sup>2</sup></>) },
    { key: "clamping_force", label: "Clamping Force",  tol: "±5",  unit: (<><span>kg/cm</span><sup>3</sup></>) },
    { key: "oil_temp", label: "OIL TEMP",        tol: "±3",  unit: "°C" },
  ];

  // สร้าง state สำหรับเก็บค่าจาก input
  const [form, setForm] = useState({});
  // state สำหรับเก็บ field ที่ต้องแสดงสีฟ้า (local highlight)
  const [localFlash, setLocalFlash] = useState([]);
  // state สำหรับเก็บค่าล่าสุดเพื่อเปรียบเทียบ
  const [lastData, setLastData] = useState({});

  // รับข้อมูลจาก initialData และตรวจสอบการเปลี่ยนแปลงแต่ละช่อง
  useEffect(() => {
    if (initialData) {
      // ตรวจสอบการเปลี่ยนแปลงก่อนอัปเดต form
      if (Object.keys(lastData).length > 0) {
        const changedCells = [];
        
        Object.keys(initialData).forEach(key => {
          const newValue = initialData[key];
          const oldValue = lastData[key];
          
          // เปรียบเทียบค่าแต่ละช่อง ถ้าต่างกันให้เพิ่มเข้า changedCells
          if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
            changedCells.push(key);
          }
        });

        if (changedCells.length > 0) {
          console.log('INJECTIONActual changed cells:', changedCells);
          setLocalFlash(changedCells);
          
          // ลบสีหลังจาก 5 วินาที
          setTimeout(() => {
            setLocalFlash([]);
          }, 30000);
        }
      }
      
      // อัปเดต form และ lastData
      setForm(initialData);
      setLastData(JSON.parse(JSON.stringify(initialData)));
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (key, value) => {
    const newForm = { ...form, [key]: value };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div>
      <div className={tableStyles.injectionSection}>
        <div className={tableStyles.injectionTitle}>INJECTION ACTUAL</div>
        <table className={tableStyles.injectionTable}>
          <thead>
            <tr>
              <th colSpan={2}></th>
              <th className={tableStyles.stdCol}>STD</th>
              <th colSpan={2} className={tableStyles.actualCol}>Actual</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ key, label, tol, unit }, i) => {
              // ตรวจสอบว่าช่องนี้ควรเปลี่ยนสีหรือไม่
              const shouldHighlight = localFlash.includes(key);
              
              return (
                <tr key={i}>
                  <td colSpan={2} className={tableStyles.labelCol}>{label}</td>
                  <td className={tableStyles.stdColBg}></td>
                  <td colSpan={2} className={tableStyles.actualCol} style={{
                    backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                    border: shouldHighlight ? '2px solid #0066cc' : '',
                    transition: 'all 0.3s ease'
                  }}>
                    <input
                      type="text"
                      // style={{ 
                      //   width: '90%', 
                      //   border: 'none', 
                      //   background: shouldHighlight ? '#cce6ff' : 'transparent', 
                      //   fontSize: '16px', 
                      //   padding: '2px 4px',
                      //   transition: 'all 0.3s ease',
                      //   outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                      //   color: shouldHighlight ? '#003366' : 'inherit'
                      // }}
                      value={form[key] || ""}
                      onChange={e => handleInputChange(key, e.target.value)}
                    />
                  </td>
                  <td className={tableStyles.unitCol}>{unit} {tol}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
