

import React, { useState, useEffect } from "react";
import styles from "./css/ValveGate.module.css";

const header = ["Z1", "Z2", "Z3", "Z4", "Z5", "Z6"];

export default function ValveGate({ onDataChange, initialData }) {
  // สร้าง state สำหรับเก็บค่าจาก input (object per header)
  const [form, setForm] = useState({
    ON: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
    OFF: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {})
  });

  // รับข้อมูลจาก initialData เมื่อเปลี่ยน พร้อม fallback ถ้าไม่มี ON หรือ OFF
  useEffect(() => {
    if (initialData) {
      setForm({
        ON: initialData.ON ? initialData.ON : header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
        OFF: initialData.OFF ? initialData.OFF : header.reduce((acc, h) => ({ ...acc, [h]: "" }), {})
      });
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (rowKey, idx, value) => {
    const key = header[idx];
    const newForm = {
      ...form,
      [rowKey]: {
        ...form[rowKey],
        [key]: value
      }
    };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div className={styles.wrap}>
      <div className={styles.sectionTitle} style={{ textAlign: 'center' }}>
        <span style={{ fontWeight: 'bold' }}>Valve Gate ( Sec )</span>
      </div>
      <table className={styles.table}>
        <colgroup>
          <col />
          {header.map((_, i) => <col key={i} />)}
        </colgroup>
        <thead>
          <tr>
            <th></th>
            {header.map(h => (
              <th key={h} className={styles.head}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {/* ON row */}
          <tr>
            <td className={styles.head}>ON</td>
            {header.map((h, idx) => (
              <td key={h} className={styles.yellow}>
                <input
                  type="text"
                  style={{ width: '100%' }}
                  value={form.ON[h]}
                  onChange={e => handleInputChange("ON", idx, e.target.value)}
                />
              </td>
            ))}
            <td className={styles.tolerance} rowSpan={2} style={{ fontWeight: 'bold', fontSize: '16px', verticalAlign: 'middle' }}>±3 SEC.</td>
          </tr>
          {/* OFF row */}
          <tr>
            <td className={styles.head}>OFF</td>
            {header.map((h, idx) => (
              <td key={h} className={styles.yellow}>
                <input
                  type="text"
                  style={{ width: '100%' }}
                  value={form.OFF[h]}
                  onChange={e => handleInputChange("OFF", idx, e.target.value)}
                />
              </td>
            ))}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
