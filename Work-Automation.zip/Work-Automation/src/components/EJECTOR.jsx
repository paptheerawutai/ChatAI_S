
import React, { useState, useEffect } from "react";
import styles from "./css/EJECTOR.module.css";

const header = ["BWD.", "FWDL.", "FWDH.", "HOLD"];
const rows = ["PRESSURE", "SPEED", "TIME", "POSITION"];

export default function EJECTOR({ onDataChange, initialData }) {
  // สร้าง state สำหรับเก็บค่าจาก input (object per header)
  const [form, setForm] = useState(
    rows.reduce((acc, row) => ({
      ...acc,
      [row]: header.reduce((hAcc, h) => ({ ...hAcc, [h]: "" }), {})
    }), {})
  );
  const [forwardPosi, setForwardPosi] = useState("");
  // state สำหรับเก็บ field ที่ต้องแสดงสีฟ้า (local highlight)
  const [localFlash, setLocalFlash] = useState([]);
  // state สำหรับเก็บค่าล่าสุดเพื่อเปรียบเทียบ
  const [lastData, setLastData] = useState({});

  // รับข้อมูลจาก initialData และตรวจสอบการเปลี่ยนแปลงแต่ละช่อง
  useEffect(() => {
    if (initialData) {
      // ตรวจสอบการเปลี่ยนแปลงก่อนอัปเดต form
      if (Object.keys(lastData).length > 0) {
        const changedCells = [];
        
        // ตรวจสอบ rows data
        rows.forEach(row => {
          if (initialData[row] && lastData[row]) {
            header.forEach(h => {
              const newValue = initialData[row][h];
              const oldValue = lastData[row][h];
              
              if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
                changedCells.push(`${row}.${h}`);
              }
            });
          }
        });
        
        // ตรวจสอบ forwardPosi
        if (initialData.forwardPosi !== lastData.forwardPosi && initialData.forwardPosi !== undefined && initialData.forwardPosi !== null && initialData.forwardPosi !== '') {
          changedCells.push('forwardPosi');
        }

        if (changedCells.length > 0) {
          console.log('EJECTOR changed cells:', changedCells);
          setLocalFlash(changedCells);
          
          // ลบสีหลังจาก 5 วินาที
          setTimeout(() => {
            setLocalFlash([]);
          }, 30000);
        }
      }
      
      // อัปเดต form และ lastData
      setForm(
        rows.reduce((acc, row) => ({
          ...acc,
          [row]: initialData[row]
            ? header.reduce((hAcc, h) => ({ ...hAcc, [h]: initialData[row][h] || "" }), {})
            : header.reduce((hAcc, h) => ({ ...hAcc, [h]: "" }), {})
        }), {})
      );
      setForwardPosi(initialData.forwardPosi || "");
      setLastData(JSON.parse(JSON.stringify(initialData)));
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (rowKey, idx, value) => {
    const key = header[idx];
    const newForm = {
      ...form,
      [rowKey]: {
        ...form[rowKey],
        [key]: value
      }
    };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange({ ...newForm, forwardPosi });
  };

  // สำหรับ 1ST FORWARD POSI
  const handleForwardPosiChange = (value) => {
    setForwardPosi(value);
    if (onDataChange) onDataChange({ ...form, forwardPosi: value });
  };

  return (
    <div>
      <div style={{ fontWeight: "bold", fontSize: "20px", marginBottom: "8px", margin: "10px" }}>EJECTOR</div>
      <table className={styles.table} style={{ background: '#fff', borderRight: 'none', borderLeft: 'none', borderTop: 'none', borderBottom: 'none' }}>
        <thead>
          <tr>
            <th className={styles.noborder}></th>
            {header.map(h => (
              <th key={h} className={styles.head}>{h}</th>
            ))}
            <th className={styles.noborder}></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rIdx) => (
            <tr key={row}>
              <td className={styles.label}>{row}</td>
              {header.map((h, idx) => {
                // ตรวจสอบว่าช่องนี้ควรเปลี่ยนสีหรือไม่
                const cellKey = `${row}.${h}`;
                const shouldHighlight = localFlash.includes(cellKey);
                
                return (
                  <td key={h + idx} className={`${styles.grid} ${styles.yellow}`} style={{
                    backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                    border: shouldHighlight ? '2px solid #0066cc' : '',
                    transition: 'all 0.3s ease'
                  }}>
                    <input
                      type="text"ห
                      // style={{ 
                      //   width: '90%', 
                      //   border: 'none', 
                      //   background: shouldHighlight ? '#cce6ff' : 'transparent', 
                      //   fontSize: '16px', 
                      //   padding: '2px 4px',
                      //   outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                      //   color: shouldHighlight ? '#003366' : 'inherit',
                      //   transition: 'all 0.3s ease'
                      // }}
                      value={form[row][h]}
                      onChange={e => handleInputChange(row, idx, e.target.value)}
                    />
                  </td>
                );
              })}
              <td className={styles.tol}>
                {row === "PRESSURE" && <>±10 kg/cm<sup>2</sup></>}
                {row === "SPEED" && <>±10 mm/s</>}
                {row === "TIME" && <>±3 s</>}
                {row === "POSITION" && <>±10 mm</>}
              </td>
            </tr>
          ))}
          {/* 1ST FORWARD POSI */}
          <tr>
            <td></td>
            <td className={styles.label}>1ST FORWARD POSI</td>
            <td></td>
            <td className={`${styles.grid} ${styles.yellow}`} style={{
              backgroundColor: localFlash.includes('forwardPosi') ? '#e6f3ff' : '',
              border: localFlash.includes('forwardPosi') ? '2px solid #0066cc' : '',
              transition: 'all 0.3s ease'
            }}>
              <input
                type="text"
                style={{ 
                  width: '90%', 
                  border: 'none', 
                  background: localFlash.includes('forwardPosi') ? '#cce6ff' : 'transparent', 
                  fontSize: '16px', 
                  padding: '2px 4px',
                  outline: localFlash.includes('forwardPosi') ? '2px solid #0080ff' : 'none',
                  color: localFlash.includes('forwardPosi') ? '#003366' : 'inherit',
                  transition: 'all 0.3s ease'
                }}
                value={forwardPosi}
                onChange={e => handleForwardPosiChange(e.target.value)}
              />
            </td>
            <td className={styles.noborder}></td>
            <td className={styles.tol}>mm</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
