import React, { useState, useEffect } from "react";
import styles from "./css/MOLDCLOSE.module.css";

const header = ["HS", "LS", "LP", "HP1", "HP2"];

export default function MOLDCLOSE({ onDataChange, initialData }) {
  // สร้าง state สำหรับเก็บค่าจาก input (object per header)
  const [form, setForm] = useState({
    PRESSURE: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
    SPEED: header.reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
    POSITION: header.slice(1, 4).reduce((acc, h) => ({ ...acc, [h]: "" }), {}),
    TIME: header.slice(1, 3).reduce((acc, h) => ({ ...acc, [h]: "" }), {})
  });
  // state สำหรับเก็บ field ที่ต้องแสดงสีฟ้า (local highlight)
  const [localFlash, setLocalFlash] = useState([]);
  // state สำหรับเก็บค่าล่าสุดเพื่อเปรียบเทียบ
  const [lastData, setLastData] = useState({});

  // รับข้อมูลจาก initialData และตรวจสอบการเปลี่ยนแปลงแต่ละช่อง
  useEffect(() => {
    if (initialData) {
      // ตรวจสอบการเปลี่ยนแปลงก่อนอัปเดต form
      if (Object.keys(lastData).length > 0) {
        const changedCells = [];
        
        // ตรวจสอบ PRESSURE, SPEED
        ['PRESSURE', 'SPEED'].forEach(section => {
          if (initialData[section] && lastData[section]) {
            header.forEach(h => {
              const newValue = initialData[section][h];
              const oldValue = lastData[section][h];
              
              if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
                changedCells.push(`${section}.${h}`);
              }
            });
          }
        });
        
        // ตรวจสอบ POSITION (LS, LP, HP1)
        if (initialData.POSITION && lastData.POSITION) {
          header.slice(1, 4).forEach(h => {
            const newValue = initialData.POSITION[h];
            const oldValue = lastData.POSITION[h];
            
            if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
              changedCells.push(`POSITION.${h}`);
            }
          });
        }
        
        // ตรวจสอบ TIME (LS, LP)
        if (initialData.TIME && lastData.TIME) {
          header.slice(1, 3).forEach(h => {
            const newValue = initialData.TIME[h];
            const oldValue = lastData.TIME[h];
            
            if (newValue !== oldValue && newValue !== undefined && newValue !== null && newValue !== '') {
              changedCells.push(`TIME.${h}`);
            }
          });
        }

        if (changedCells.length > 0) {
          console.log('MOLDCLOSE changed cells:', changedCells);
          setLocalFlash(changedCells);
          
          // ลบสีหลังจาก 5 วินาที
          setTimeout(() => {
            setLocalFlash([]);
          }, 30000);
        }
      }
      
      // อัปเดต form และ lastData
      setForm({
        PRESSURE: header.reduce((acc, h) => ({ ...acc, [h]: initialData.PRESSURE?.[h] || "" }), {}),
        SPEED: header.reduce((acc, h) => ({ ...acc, [h]: initialData.SPEED?.[h] || "" }), {}),
        POSITION: header.slice(1, 4).reduce((acc, h) => ({ ...acc, [h]: initialData.POSITION?.[h] || "" }), {}),
        TIME: header.slice(1, 3).reduce((acc, h) => ({ ...acc, [h]: initialData.TIME?.[h] || "" }), {})
      });
      setLastData(JSON.parse(JSON.stringify(initialData)));
    }
  }, [initialData]);

  // เมื่อกรอกข้อมูลในช่อง input
  const handleInputChange = (rowKey, idx, value) => {
    let key;
    if (rowKey === "POSITION") {
      key = header.slice(1, 4)[idx];
    } else if (rowKey === "TIME") {
      key = header.slice(1, 3)[idx];
    } else {
      key = header[idx];
    }
    const newForm = {
      ...form,
      [rowKey]: {
        ...form[rowKey],
        [key]: value
      }
    };
    setForm(newForm);
    // ส่งข้อมูลกลับไป parent ทุกครั้งที่เปลี่ยน
    if (onDataChange) onDataChange(newForm);
  };

  return (
    <div>
      <div style={{ fontWeight: "bold", fontSize: "20px", marginBottom: "8px" }}>MOLD CLOSE</div>
      <table className={styles.table}>
        <thead>
          <tr>
            <th></th>
            {header.map(h => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {/* PRESSURE */}
          <tr>
            <td style={{ fontWeight: "bold", textAlign: "left" }}>PRESSURE</td>
            {header.map((h, idx) => {
              const cellKey = `PRESSURE.${h}`;
              const shouldHighlight = localFlash.includes(cellKey);
              
              return (
                <td key={h} className={styles.yellow} style={{
                  backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                  border: shouldHighlight ? '2px solid #0066cc' : '',
                  transition: 'all 0.3s ease'
                }}>
                  <input
                    type="text"
                    className={styles.input}
                    // style={{
                    //   background: shouldHighlight ? '#cce6ff' : 'transparent',
                    //   outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                    //   color: shouldHighlight ? '#003366' : 'inherit',
                    //   transition: 'all 0.3s ease'
                    // }}
                    value={form.PRESSURE[h]}
                    onChange={e => handleInputChange("PRESSURE", idx, e.target.value)}
                  />
                </td>
              );
            })}
          </tr>
          {/* SPEED */}
          <tr>
            <td style={{ fontWeight: "bold", textAlign: "left" }}>SPEED</td>
            {header.map((h, idx) => {
              const cellKey = `SPEED.${h}`;
              const shouldHighlight = localFlash.includes(cellKey);
              
              return (
                <td key={h} className={styles.yellow} style={{
                  backgroundColor: shouldHighlight ? '#e6f3ff' : '',
                  border: shouldHighlight ? '2px solid #0066cc' : '',
                  transition: 'all 0.3s ease'
                }}>
                  <input
                    type="text"
                    className={styles.input}
                    style={{
                      background: shouldHighlight ? '#cce6ff' : 'transparent',
                      outline: shouldHighlight ? '2px solid #0080ff' : 'none',
                      color: shouldHighlight ? '#003366' : 'inherit',
                      transition: 'all 0.3s ease'
                    }}
                    value={form.SPEED[h]}
                    onChange={e => handleInputChange("SPEED", idx, e.target.value)}
                  />
                </td>
              );
            })}
          </tr>
          {/* POSITION */}
          <tr>
            <td></td>
            <td style={{ fontWeight: "bold", textAlign: "left" }}>POSITION</td>
            {header.slice(1, 4).map((h, idx) => (
              <td key={h} className={styles.yellow}>
                <input
                  type="text"
                  className={styles.input}
                  value={form.POSITION[h]}
                  onChange={e => handleInputChange("POSITION", idx, e.target.value)}
                />
              </td>
            ))}
            <td></td>
          </tr>
          {/* TIME */}
          <tr>
            <td></td>
            <td style={{ fontWeight: "bold", textAlign: "left" }}>TIME</td>
            {header.slice(1, 3).map((h, idx) => (
              <td key={h} className={styles.yellow}>
                <input
                  type="text"
                  className={styles.input}
                  value={form.TIME[h]}
                  onChange={e => handleInputChange("TIME", idx, e.target.value)}
                />
              </td>
            ))}
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}